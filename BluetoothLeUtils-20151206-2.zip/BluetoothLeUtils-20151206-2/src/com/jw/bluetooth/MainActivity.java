package com.jw.bluetooth;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.jw.bluetooth.adapter.ScanAdapter;
import com.jw.bluetooth.adapter.ScanAdapter.OnDownloadListener;
import com.jw.bluetooth.le.ILeController.CmdCallback;
import com.jw.bluetooth.le.ILeController.OnGattLeCallback;
import com.jw.bluetooth.models.ScanEntity;
import com.jw.bluetooth.utils.ByteStringUtils;
import com.jw.bluetooth.utils.Tools;
import com.jw.bluetooth.widget.MySlipSwitch;
import com.jw.bluetooth.widget.MySlipSwitch.OnSwitchListener;

public class MainActivity extends Activity implements OnClickListener{
	private Context context;
	private MySlipSwitch slipswitch_MSL;
	private ListView lv;
	private TextView tv_scanning,tv_text;
	ScanAdapter sadapter;
	ImageView iv;
	String ping="810011303132333435363738394142434445465A";
	String msg="83004700200000000040000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F";
	String bf="BF00";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.scan);
		setupView();
		setListener();
		
		LeController.INSTANCE.run(this);
		if(!LeController.INSTANCE.isBluetoothLeOpen()){
			LeController.INSTANCE.openBluetoothLe();
			/**
			 * 打开系统蓝牙设置界面
			 */
//			Intent settingsIntent = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
//		      startActivity(settingsIntent);
		}
		LeController.INSTANCE.setOnGattLeCallback(new OnGattLeCallback() {
			
			@Override
			public void onScanResult(BluetoothDevice device, int rssi, byte[] scanRecord) {
				// TODO Auto-generated method stub
				((Activity)context).runOnUiThread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						sadapter.setList(LeController.INSTANCE.workingDevices);
					}
				});
				
			}
			
			@Override
			public <T> void onScanPeriodResults(ArrayList<T> results) {
				// TODO Auto-generated method stub
				((Activity)context).runOnUiThread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						if(LeController.INSTANCE.connectState){
							LeController.INSTANCE.workingDevices=
									Tools.insert(LeController.INSTANCE.workingDevices,
											LeController.INSTANCE.mCurrentEntity);
						}
//						Log.e("", "size:"+BluetoothLeController.getLeController().getScanList().size());
						sadapter.setList(LeController.INSTANCE.workingDevices);
					}
				});
				
				
			}
			
			@Override
			public void onConnectionStateChange(BluetoothGatt gatt, final int state,
					final boolean isConnect) {
				// TODO Auto-generated method stub
				((Activity)context).runOnUiThread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						if(isConnect){
							if(state==100){
								LeController.INSTANCE.isAutoReconnect=true;
								LeController.INSTANCE.connectState=true;
								LeController.INSTANCE.mCurrentEntity.setState(100);
								LeController.INSTANCE.workingDevices=
										Tools.insert(LeController.INSTANCE.workingDevices,LeController.INSTANCE.mCurrentEntity);
								sadapter.dataChange(LeController.INSTANCE.mCurrentEntity);
								
							}
						}else{
							//fresh item status of listview
							
							if(LeController.INSTANCE.mCurrentEntity!=null){
								Log.e("", "DISCONNECT:fresh ui...");
								LeController.INSTANCE.mCurrentEntity.setState(state);
								sadapter.dataChange(LeController.INSTANCE.mCurrentEntity);
							}
							
							//reconnect.....
							if(LeController.INSTANCE.mCurrentEntity!=null
									&& LeController.INSTANCE.isAutoReconnect){
								sadapter.connectLe(LeController.INSTANCE.mCurrentEntity);
							}
						}
					}
				});
				
			}

			@Override
			public void onApduback(final byte[] results) {
				// TODO Auto-generated method stub
				Log.e("", "onApduback:"+(results!=null ? ByteStringUtils.Byte2hexString(results):"results=null"));
				((Activity)context).runOnUiThread(new Runnable() {
					
					@Override
					public void run() {
						tv_text.setText("onApduback:"+(results!=null ? ByteStringUtils.Byte2hexString(results):"results=null"));
					}
				});
			}
		});
		

		sadapter=new ScanAdapter(LeController.INSTANCE.workingDevices, context);
		sadapter.setOnDownloadListener(new OnDownloadListener() {

			@Override
			public void onDownload(int position, ArrayList<ScanEntity> list) {
				
				
			}

		});
		
		lv.setAdapter(sadapter);
	}

	public void setupView() {
		context=this;
		slipswitch_MSL = (MySlipSwitch)findViewById(R.id.sw_scan);
		lv=(ListView) findViewById(R.id.lv_scan);
		tv_scanning=(TextView) findViewById(R.id.tv_scaning);
		tv_scanning.setVisibility(View.INVISIBLE);
		
		tv_text=(TextView) findViewById(R.id.tv_text);
		
		findViewById(R.id.btn_poweron).setOnClickListener(this);
		findViewById(R.id.btn_poweroff).setOnClickListener(this);
		findViewById(R.id.btn_reset).setOnClickListener(this);
		findViewById(R.id.btn_ping).setOnClickListener(this);
		
		findViewById(R.id.btn_msg).setOnClickListener(this);
		findViewById(R.id.btn_bf).setOnClickListener(this);
		
	}
	
	
	
	
	public void setListener() {
		slipswitch_MSL.setOnSwitchListener(new OnSwitchListener() {
				@Override
				public void onSwitched(boolean isSwitchOn) {
					if(isSwitchOn) {
						tv_scanning.setVisibility(View.VISIBLE);
//						LeController.INSTANCE.startLeScan(); 
						
						LeController.INSTANCE.startScanLe(); 
					} else {
						tv_scanning.setVisibility(View.INVISIBLE);
//						LeController.INSTANCE.stopLeScan(); 
						
						LeController.INSTANCE.stopScanLe(); 
					}
				}
			});
		
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		if(v.getId()==R.id.btn_poweron){
//			
//			Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//            startActivityForResult(intent, 0);
			
			if(LeController.INSTANCE.connectState){
				LeController.INSTANCE.poweron(new CmdCallback<byte[]>() {
					
					@Override
					public void onSuccess(Object result) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void onError(byte[] ex, int errorCode) {
						// TODO Auto-generated method stub
						
					}
				});
			}
		}else if(v.getId()==R.id.btn_poweroff){
			if(LeController.INSTANCE.connectState){
				LeController.INSTANCE.poweroff(new CmdCallback<byte[]>() {
					
					@Override
					public void onSuccess(Object result) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void onError(byte[] ex, int errorCode) {
						// TODO Auto-generated method stub
						
					}
				});
			}
		}else if(v.getId()==R.id.btn_reset){
			if(LeController.INSTANCE.connectState){
				LeController.INSTANCE.reset(new CmdCallback<byte[]>() {
					
					@Override
					public void onSuccess(Object result) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void onError(byte[] ex, int errorCode) {
						// TODO Auto-generated method stub
						
					}
				});
			}
		}else if(v.getId()==R.id.btn_ping){
			byte[] datas=ByteStringUtils.stringToByteArr(ping);
			Log.e("ping",ByteStringUtils.Byte2hexString(datas));
			if(LeController.INSTANCE.connectState){
				
				LeController.INSTANCE.ping(datas,new CmdCallback<byte[]>() {
					
					@Override
					public void onSuccess(final Object result) {
						// TODO Auto-generated method stub
						((Activity)context).runOnUiThread(new Runnable() {
							
							@Override
							public void run() {
								if(result!=null && result instanceof byte[]){
									byte[] datas=(byte[]) result;
									Log.e("onSuccess",ByteStringUtils.Byte2hexString(datas));
									tv_text.setText("onSuccess："+ByteStringUtils.Byte2hexString(datas));
								}
								
							}
						});
						
					}
					
					@Override
					public void onError(final byte[] ex, final int errorCode) {
						// TODO Auto-generated method stub
						Log.e("onError",errorCode+"---"+ByteStringUtils.Byte2hexString(ex));
						((Activity)context).runOnUiThread(new Runnable() {
							
							@Override
							public void run() {
								tv_text.setText("onError:"+errorCode+"---"+ByteStringUtils.Byte2hexString(ex));
							}
						});
					}
				});
			}
		}else if(v.getId()==R.id.btn_msg){
			byte[] datas=ByteStringUtils.stringToByteArr(msg);
			Log.e("msg",ByteStringUtils.Byte2hexString(datas));
			if(LeController.INSTANCE.connectState){
				
				LeController.INSTANCE.msgapdu(datas,new CmdCallback<Boolean>() {
					
					@Override
					public void onSuccess(Object result) {
						// TODO Auto-generated method stub
						if(result!=null && result instanceof byte[]){
							byte[] datas=(byte[]) result;
							Log.e("onSuccess",ByteStringUtils.Byte2hexString(datas));
							
						}
					}
					
					@Override
					public void onError(byte[] ex, int errorCode) {
						// TODO Auto-generated method stub
						Log.e("onError",errorCode+"---"+ByteStringUtils.Byte2hexString(ex));
					}
				});
			}
		}else if(v.getId()==R.id.btn_bf){
			byte[] datas=ByteStringUtils.stringToByteArr(bf);
			if(LeController.INSTANCE.connectState && datas!=null && datas.length>0){
				
				Log.e("msg",ByteStringUtils.Byte2hexString(datas));
				LeController.INSTANCE.bfapdu(datas,new CmdCallback<Boolean>() {
					
					@Override
					public void onSuccess(Object result) {
						// TODO Auto-generated method stub
						if(result!=null && result instanceof Boolean){
							Log.e("onSuccess",""+((Boolean)result));
						}
						
					}
					
					@Override
					public void onError(byte[] ex, int errorCode) {
						// TODO Auto-generated method stub
						Log.e("onError",errorCode+"---"+ByteStringUtils.Byte2hexString(ex));
					}
				});
			}
		}
		
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		if(requestCode==0)
		{
		   super.onActivityResult(requestCode, resultCode, data);
                   Bundle Extras = data.getExtras(); 
                   Bitmap mBitmap = (Bitmap)Extras.get("data"); 
                   iv.setImageBitmap(mBitmap);
		}
		else
		{
			Toast.makeText(this, "您没有拍摄照片！", Toast.LENGTH_SHORT).show();
		}
	}
}
