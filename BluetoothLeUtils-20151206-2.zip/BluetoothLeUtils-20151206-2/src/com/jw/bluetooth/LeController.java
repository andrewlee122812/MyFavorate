package com.jw.bluetooth;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;

import com.jw.bluetooth.le.ILeController;
import com.jw.bluetooth.utils.ByteStringUtils;


public class LeController extends ILeController {

	public static final LeController INSTANCE=new LeController();
	
	/******************************************************************************/

	
	
    /**
	 * Apud回调类 QuinticCallback<T>
	 *
	 * @param <T>
	 */
	public interface QuinticCallback<T>{//interface
		 void onComplete(Object result);//完成时
		/**
		 * 发生异常
		 * @param ex
		 */
		 void onError(Exception ex);
		/**
		 * 进度变更
		 * @param progress 进度值（0-100）
		 */
		 void onProgress(int progress);
	}
	public QuinticCallback<?> quinticCallback;
	
	public QuinticCallback<?> getQuinticCallback() {
		return quinticCallback;
	}
	public void setQuinticCallback(
			QuinticCallback<?> quinticCallback) {
		this.quinticCallback = quinticCallback;
	}
	/**
	 * 智能卡下电
	 * @param callback
	 */
	public void smartCardPowerOff(QuinticCallback<java.lang.Void> callback){
		try {
			Log.e("", "smartCardPowerOff");
			setQuinticCallback(callback);
			
			boolean isdisconnect=false;
			if(isdisconnect){
			}
			if(this.quinticCallback!=null){
				this.quinticCallback.onComplete(isdisconnect);;
			}
					
			Log.i("smartCardPowerOff", ""+isdisconnect);
		} catch (Exception e) {
			if(this.quinticCallback!=null){
				this.quinticCallback.onError(e);
			}else{
				e.printStackTrace();
			}
		}
	}

	/**
	 * 智能卡上电
	 * @param callback
	 */
	public void smartCardPowerOn(QuinticCallback<java.lang.Void> callback){
		try {
			setQuinticCallback(callback);
			boolean isSuccess=false;
			if(this.quinticCallback!=null){
				this.quinticCallback.onComplete(isSuccess);;
			}
		} catch (Exception e) {
			if(this.quinticCallback!=null){
				this.quinticCallback.onError(e);
			}else{
				e.printStackTrace();
			}
		}
	}
	/**
	 * 智能卡复位
	 * @param callback
	 */
	public void smartCardReset(QuinticCallback<java.lang.Void> callback){
		try {
			setQuinticCallback(callback);
			boolean isSuccess=false;
			if(this.quinticCallback!=null){
				this.quinticCallback.onComplete(isSuccess);;
			}
		} catch (Exception e) {
			if(this.quinticCallback!=null){
				this.quinticCallback.onError(e);
			}else{
				e.printStackTrace();
			}
		}
	}
	/**
	 * 智能卡透传
	 * @param data
	 * @param callback
	 */
	public void smartCardTransmission(byte[] data, QuinticCallback<byte[]> callback){
		if( data==null || (data!=null && data.length==0)){
			return ;
		}
		try {
			setQuinticCallback(callback);
			
			responseDataList.clear();
			
			requestDatas=data;
			decodingRequest(data);//给requestDataList赋值
		} catch (Exception e) {
			if(this.quinticCallback!=null){
				this.quinticCallback.onError(e);
			}else{
				e.printStackTrace();
			}
		}
	}
	
	
}
