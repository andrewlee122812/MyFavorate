package com.jw.bluetooth.adapter;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.jw.bluetooth.LeController;
import com.jw.bluetooth.R;
import com.jw.bluetooth.models.ScanEntity;



public class ScanAdapter extends BaseAdapter {
	
	private ArrayList<ScanEntity> list;
	private Context context;
	ViewHodler hodler;
	int downx=0;
	int downy=0;
	ViewHodler view=null;
	private LayoutInflater inflater;
	public boolean isConnecting=false;
	private ProgressDialog progressDialog;

	public ScanAdapter(ArrayList<ScanEntity> devices,Context context) {
		if(devices!=null){
			this.list=devices;
		}else{
			list=new ArrayList<ScanEntity>();
		}
		this.context=context;
		inflater=LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public ScanEntity getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public ArrayList<ScanEntity> getList() {
		return list;
	}

	public void setList(ArrayList<ScanEntity> list) {
		this.list = list;
		notifyDataSetChanged();
	}

	public void freshList(){
		notifyDataSetChanged();
	}
	
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		if(convertView==null){
			hodler=new ViewHodler();
			convertView=inflater.inflate(R.layout.scan_list_item, null);
			hodler.btn_cancel=(Button) convertView.findViewById(R.id.btn_cancel);
			hodler.tv_blename=(TextView) convertView.findViewById(R.id.tv_blename);
			hodler.tv_connect=(TextView) convertView.findViewById(R.id.tv_connect);
			hodler.btn_left=(Button) convertView.findViewById(R.id.btn_left);
			convertView.setTag(hodler);
		}else{
			hodler=(ViewHodler) convertView.getTag();
		}
		
		/**
		 * 加载时默认的命名、断开Button不可见
		 */
		if(hodler.btn_cancel.getVisibility()==View.VISIBLE){
			hodler.btn_cancel.setVisibility(View.GONE);
		}
		if(hodler.btn_left.getVisibility()==View.VISIBLE){
			hodler.btn_left.setVisibility(View.GONE);
		} 
		if(list.size()<=position){
			return convertView;
		}
		final ScanEntity e = list.get(position);

		convertView.setOnTouchListener(new OnTouchListener(){
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				final ViewHodler holder = (ViewHodler) v.getTag();
				
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
						
					downx=(int)event.getX();
					downy=(int)event.getY();
					if(view!=null){
						if(view.btn_cancel.getVisibility()==View.VISIBLE){
							view.btn_cancel.setVisibility(View.GONE);
							view=null;
							return false;
						}
						if(view.btn_left.getVisibility()==View.VISIBLE){
							view.btn_left.setVisibility(View.GONE);
							view=null;
							return false;
						}
					}
					v.setBackgroundColor(android.graphics.Color.parseColor("#F2F2F2"));
					
					break;
				case MotionEvent.ACTION_MOVE:
					if(downx-(int)event.getX()>40){//向右滑
						holder.btn_cancel.setVisibility(View.VISIBLE);
						holder.btn_left.setVisibility(View.GONE);
						view=holder;
					
					}else if((int)event.getX()-downx>40){
						holder.btn_left.setVisibility(View.VISIBLE);
						holder.btn_cancel.setVisibility(View.GONE);
						view=holder;
					}else{
						holder.btn_cancel.setVisibility(View.GONE);
						holder.btn_left.setVisibility(View.GONE);
						view=null;
					}
					break;
				case MotionEvent.ACTION_UP:
					v.setBackgroundColor(Color.TRANSPARENT);
					if(Math.abs(downx-(int)event.getX())<=30){//onClick相当于点击效果
						if(holder.btn_cancel.getVisibility()==View.VISIBLE){
							holder.btn_cancel.setVisibility(View.GONE);
							view=null;
						}else if(holder.btn_left.getVisibility()==View.VISIBLE){
							holder.btn_left.setVisibility(View.GONE);
							view=null;
						}else{
							//如果是没有连接
							if(e.getState()!=100
									&& !LeController.INSTANCE.connectState){
								
								if(LeController.INSTANCE.mCurrentEntity!=null
										&& LeController.INSTANCE.mCurrentEntity.getState()==1){
									Toast.makeText(context,"设备=>"+ LeController.INSTANCE.mCurrentEntity.getDevice().getAddress()+" 正在连接...", 1000).show();
								}else{
									
									connectLe(e);
								}
									
							}else{
								Toast.makeText(context, "已经有设备连接成功", 1000).show();
							}
						}
					}
					break;
				default:
					v.setBackgroundColor(Color.parseColor("#FFFFFF"));
					break;
				}
				return true;
			}

		});
		
		hodler.tv_blename.setText(e.getDevice().getName()+"->"+e.getDevice().getAddress());
		String status="";
		if(e.getState()==-1 || e.getState()==1){
			status=context.getResources().getString(R.string.unconnect);
			
		}else if(e.getState()==100){
			status=context.getResources().getString(R.string.connected);
		}
		hodler.tv_connect.setText(status);
		hodler.btn_cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.e("", "right.onClick");
				//放弃控制
				if(e.getState()==100
						&& LeController.INSTANCE.connectState){
					LeController.INSTANCE.disconnect();
					LeController.INSTANCE.isAutoReconnect=false;
				}else{
					Toast.makeText(context, "未连接", 1000).show();
				}
			}
		});
		hodler.btn_left.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.e("", "left.onClick");
				
				if(LeController.INSTANCE.connectState){
					Toast.makeText(context, "连续发送", 1000).show();
					if(mOnDownloadListener!=null){
						mOnDownloadListener.onDownload(position,list);
					}
				}else{
					Toast.makeText(context, "未连接", 1000).show();
					
				}
				
			}
		}); 
		return convertView;
	}

	Handler mHandler=null;
	public void connectLe(final ScanEntity e) {
//		if(!isConnecting){
			LeController.INSTANCE.stopScanLe();
			e.setState(1);
			LeController.INSTANCE.mCurrentEntity=e;
			LeController.INSTANCE.connectLeDevice(e.getDevice());
			
			progressDialog = new ProgressDialog(context); 
			progressDialog.setProgressStyle(ProgressDialog.THEME_HOLO_DARK); 
//			progressDialog.setIcon(R.drawable.alert_dialog_icon); 
			progressDialog.setMessage(context.getResources().getString(R.string.connecting)); 
			progressDialog.setCancelable(false);
			progressDialog.show();
			
			
//			isConnecting=true;
			mHandler=new Handler();
			mHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					((Activity)context).runOnUiThread(new Runnable() {
						@Override
						public void run() {
							if(progressDialog!=null && progressDialog.isShowing()){
								progressDialog.dismiss();
								progressDialog.cancel();
//								isConnecting=false;
							}
						}
					});
				}
			},15000);
//		}
	}
	
	public ProgressDialog getProgressDialog() {
		return progressDialog;
	}

	class ViewHodler{
		private Button btn_cancel,btn_left;
		private TextView tv_connect,tv_blename;
	}
	
	public void dataChange(ScanEntity sdevice){
		if(sdevice!=null){
			if(list!=null){
				if(list.size()>=0){
					for(int i=0;i<list.size();i++){
						if(list.get(i).getDevice().getAddress().equals(sdevice.getDevice().getAddress())){
							list.get(i).setState(sdevice.getState());
							notifyDataSetChanged();
							if(progressDialog!=null && progressDialog.isShowing()){
								progressDialog.dismiss();
								progressDialog.cancel();
							}
							break;
						}
					}
				}else{
					list.add(sdevice);
					notifyDataSetChanged();
					if(progressDialog!=null && progressDialog.isShowing()){
						progressDialog.dismiss();
						progressDialog.cancel();
					}
				}
				
			}
		}
	}
	
	
	/**
	 */
	private OnDownloadListener mOnDownloadListener;
	public interface OnDownloadListener{
    	/**
    	 */
    	void onDownload(int position,ArrayList<ScanEntity> list);
    }
    public OnDownloadListener getOnDownloadListener() {
		return mOnDownloadListener;
	}
	public void setOnDownloadListener(OnDownloadListener listener) {
		this.mOnDownloadListener = listener;
	}
	
}
