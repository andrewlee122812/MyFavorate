package com.jw.bluetooth.le;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;

public interface BluetoothLeGattListener {
	abstract void onConnect(BluetoothGatt gatt,boolean isConnect);
	abstract void onServicesDiscovered(BluetoothGatt gatt, boolean isSuccess);
	abstract void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, boolean isNotifySuccess);
	abstract void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic);
	abstract void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, boolean isSuccess);
	abstract void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, boolean isSuccess);
	/**
     * 蓝牙广播类：接收蓝牙广播，处理蓝牙开关操作
     * 蓝牙的4种状态：
     * 		1、BluetoothAdapter.STATE_OFF://10(处理蓝牙关闭后的事情)
     * 		2、BluetoothAdapter.STATE_TURNING_ON://11(一般不作处理)
     * 		3、BluetoothAdapter.STATE_ON://12(处理蓝牙打开后的事情)
     * 		4、BluetoothAdapter.STATE_TURNING_OFF://13(一般不作处理)
     */
    public abstract void onLeStateReceiver(int state);
}
