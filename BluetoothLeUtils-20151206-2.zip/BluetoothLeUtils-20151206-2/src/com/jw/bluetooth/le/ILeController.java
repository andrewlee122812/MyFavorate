package com.jw.bluetooth.le;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothAdapter.LeScanCallback;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.jw.bluetooth.LeController;
import com.jw.bluetooth.models.ENABLE;
import com.jw.bluetooth.models.ScanEntity;
import com.jw.bluetooth.models.ScanType;
import com.jw.bluetooth.utils.ByteStringUtils;


//TODO: change to allow multiple devices to connect.
public abstract class ILeController{
    public final static String TAG = "ILeController";
    //See ScanType enum's definition for details.
    public ScanType scanType = ScanType.ONE_OFF;
    public static final UUID CCC = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    protected LeGattCallback mGattCallback;
    private BluetoothManager mBluetoothManager;
    protected LeScanCallback mLeScanCallback;
    protected BluetoothGatt mBluetoothGatt;
    private BluetoothAdapter mBluetoothAdapter;
    
    /************************************************************/
    
    public final BluetoothLeGattListener mLeGattListener=new BluetoothLeGattListener() {
		
		@Override
		public void onConnect(BluetoothGatt gatt,boolean isConnect) {
			// TODO Auto-generated method stub
			if(isConnect){
				Log.i(TAG, gatt.getDevice().getName()+"--"+gatt.getDevice().getAddress()+" connected");
				//stop scanning
				stopLeScan();
            	Log.i(TAG,"gatt.discoverServices()? "+gatt.discoverServices());
            	
            	if(mOnGattLeCallback!=null){
					mOnGattLeCallback.onConnectionStateChange(gatt, 1, true);
				}
			}else{
				shutdownConnection();
				recoverConnectionParams();
				isNI=true;
				if(mOnGattLeCallback!=null){
					mOnGattLeCallback.onConnectionStateChange(gatt, -1, false);
				}
			}
		}
		
		@Override
		public void onServicesDiscovered(BluetoothGatt gatt,
				boolean isSuccess) {
			if(isSuccess){
				Log.i(TAG, "discover services successfully!");
				if(enableNI==ENABLE.NONE){
					if(mOnGattLeCallback!=null){
						mOnGattLeCallback.onConnectionStateChange(gatt, 100, true);
					}
				}else {
					setNotification(gatt.getService(u2f_SERV_UUID), true, enableNI);
				}
			}else{
				Log.i(TAG, "failed to discover services!");
				disconnect();
			}
		}
		
		
		@Override
		public void onDescriptorWrite(BluetoothGatt gatt,
				BluetoothGattDescriptor descriptor, boolean isNotifySuccess) {
			if(isNotifySuccess){
				Log.i(TAG, "notification successfully!");
				if(enableNI==ENABLE.NOTIFY || enableNI==ENABLE.INDICATE){
					if(mOnGattLeCallback!=null){
						mOnGattLeCallback.onConnectionStateChange(gatt, 100, true);
					}
				}else if(enableNI==ENABLE.BOTH){
					if(isNI){
						changeNotificationStatus(gatt.getService(u2f_SERV_UUID), true, ENABLE.INDICATE);
						isNI=false;
					}else{
						if(mOnGattLeCallback!=null){
							mOnGattLeCallback.onConnectionStateChange(gatt, 100, true);
						}
					}
				}
				
			}else{
				Log.i(TAG, "fail to notify!");
				disconnect();
			}
		}

		
		@Override
		public void onCharacteristicChanged(BluetoothGatt gatt,
				BluetoothGattCharacteristic characteristic) {
			byte[] datas=characteristic.getValue();
			if(datas==null){
				return ;
			}
			Log.e("onCharacteristicChanged", ""+ByteStringUtils.Byte2hexString(datas));
			if(datas.length==1){//msg/bf
				Log.e("", "datas[0]("+Integer.toHexString(datas[0]&0xFF).toUpperCase()
						+") , (SEQ^0xFF)= "+Integer.toHexString(SEQ^0xFF).toUpperCase()
						+" , (CMDId^0xFF)="+Integer.toHexString(CMDId^0xFF).toUpperCase()
						+" , u2fCmdStat="+u2fCmdStat);
				
				if(u2fCmdStat!=null){//success
						if(isFirstPackage && ((datas[0]&0xFF)==(CMDId^0xFF))){
							Log.e("", "true:isFirstPackage..");
							isFirstPackage=false;
							if(getApduDownCallback()!=null){
								getApduDownCallback().onDownSuccess(datas,true);
							}
						}else if((datas[0]&0xFF)==(SEQ^0xFF)){
							Log.e("", "false:SEQ="+SEQ);
							if(getApduDownCallback()!=null){
								getApduDownCallback().onDownSuccess(datas,false);
							}
						}else{
							Log.e("", "ERROR");
							mainHandler.sendEmptyMessage(U2F_ERROR);
						}
						
				}else{//传输失败，重传：不做任何处理，等待重传
					Log.e("len=1", "传输失败，重传：不做任何处理，等待重传");
				}
			}else{
				switch(datas[0]&0xFF){
				case 0x81://PING
					Log.e("", "0x81:PING UP");
					if(u2fCmdStat==null){
						u2fCmdStat=U2F_CMD_STAT.PING_UP;
						CMDId=0x81;
						if(getApduUpCallback()!=null){
							getApduUpCallback().onUpSuccess(datas,true);
						}
					}else{
						mainHandler.sendEmptyMessage(U2F_ERROR);
					}
					break;
				case 0x83://MSG UP
					Log.e("", "0x83:MSG UP");
					if(u2fCmdStat==null){
						u2fCmdStat=U2F_CMD_STAT.MSG_UP;
						CMDId=0x83;
						if(getApduUpCallback()!=null){
							getApduUpCallback().onUpSuccess(datas,true);
						}
					}else{
						mainHandler.sendEmptyMessage(U2F_ERROR);
					}
					break;
				case 0xBF://BF UP
					Log.e("", "0xBF:BF UP");
					if(u2fCmdStat==null){
						u2fCmdStat=U2F_CMD_STAT.BF_AUPD_UP;
						CMDId=0xBF;
						if(getApduUpCallback()!=null){
							getApduUpCallback().onUpSuccess(datas,true);
						}
					}else{
						mainHandler.sendEmptyMessage(U2F_ERROR);
					}
					break;
					default:
						if(u2fCmdStat==U2F_CMD_STAT.BF_AUPD_UP || u2fCmdStat==U2F_CMD_STAT.MSG_UP || u2fCmdStat==U2F_CMD_STAT.PING_UP){
							if(getApduUpCallback()!=null){
								getApduUpCallback().onUpSuccess(datas,false);
							}
						}else{
							Log.e("", "default:"+ByteStringUtils.Byte2hexString(new byte[]{datas[0]}));
							
						}
						break;
				}
			}
			
			
		}

		@Override
		public void onCharacteristicRead(BluetoothGatt gatt,
				BluetoothGattCharacteristic characteristic, boolean isSuccess) {
			Log.e("", "read:"+ByteStringUtils.Byte2hexString(characteristic.getValue()));
			
		}

		@Override
		public void onCharacteristicWrite(BluetoothGatt gatt,
				BluetoothGattCharacteristic characteristic, boolean isSuccess) {
			
			Log.d("onCharacteristicWrite", "u2fCmdStat="+u2fCmdStat +" write:"+ByteStringUtils.Byte2hexString(characteristic.getValue()));
		}

		@Override
		public void onLeStateReceiver(int btState) {
			// TODO Auto-generated method stub
			switch(btState){
			case BluetoothAdapter.STATE_OFF://10
				Log.e(TAG, "STATE_OFF="+btState);
				LeController.INSTANCE.stopScanLe();
				break;
			case BluetoothAdapter.STATE_TURNING_ON://11
				Log.e(TAG, "STATE_TURNING_ON="+btState);
				break;
			case BluetoothAdapter.STATE_ON://12
				Log.e(TAG, "STATE_ON="+btState);
				LeController.INSTANCE.startScanLe();
				break;
			case BluetoothAdapter.STATE_TURNING_OFF://13
				Log.e(TAG, "STATE_TURNING_OFF="+btState);
				break;
			}
		}
	};
	/**
	 * 断开设备后需要恢复默认的连接参数
	 */
	protected void recoverConnectionParams() {
		isConnectingNotClearScans=false;
		connectState=false;
		stopTimerSchedule();
	}
	
    protected Activity activity;

  /****************************************************************************/
  /**
   * Before initializing bluetooth devices, set the filter conditions
   */
  private String[] filters=new String[]{"ZC_Wristband","ZD_Wristband"};
  /**
   * 获取过滤条件
   * 默认filters=new String[]{"AST7E07"}
   * @return
   */
	public String[] getFilters() {
		return filters;
	}
	
	/**
	 * 设置过滤条件
	 * @param filters String[]
	 */
	public void setFilters(String[] filters) {
		this.filters = filters;
	}
	/**
	 * 过滤条件匹配方法
	 * @param name String
	 * @return
	 */
	private boolean isMatchFilters(String name){
		boolean isMatch=false;
		if(name!=null){
			if(filters!=null && filters.length > 0){
				for(int i=0;i<filters.length;i++){
					if(name.contains(filters[i])){
						isMatch=true;
						break;
					}
				}
			}
		}
		return isMatch;
	}
	/****************************************************************************/
    /**
	 * @return 判断 蓝牙是否可用 
	 */
    private boolean isBluetoothLeEnable() {
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager)activity.getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                return false;
            }
        }
        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            return false;
        }
        if(!activity.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)){
        	return false;
        }
        return true;
    }
    /**
     * 初始化蓝牙相关类
     * @param context
     */
    public void run(Context context) {
		this.activity = (Activity) context;
		if(mGattCallback==null){
			Log.e(TAG, "run()");
    		if (!isBluetoothLeEnable()) {
			    return;
			}else {
			}
    		setLeScanCallback();
    		registerLeReceiver(activity);
    		
    		setApduUpListener();
    	}
    }
	public void setApduUpListener() {
		
		setApduUpCallback(new ApduUpCallback<byte[]>() {

			@Override
			public void onUpSuccess(byte[] result, boolean isFirstPackage) {
				// TODO Auto-generated method stub
				if(result!=null){
					byte[] datas=result;
					if(isFirstPackage){
						CMDId=datas[0]&0xFF;
						dataReqLen=(short) ByteStringUtils.getIntFrom2Byte(new byte[]{datas[2],datas[1]});
						packagesNumber=(short) splitPackage(dataReqLen);
						HiLEN=datas[1];
						LoLEN=datas[2];
						Log.e("", "dataReqLen:"+dataReqLen+" packagesNumber:"+packagesNumber);
						
						responseDatas=null;
						responseDataList.clear();
						responseDataList.add(datas);//msgs
						
						requestCurrentDatas=new byte[]{(byte) (CMDId^0xFF)};
						sendRequestTimer();
						
					}else{
						SEQ=(byte) (datas[0]&0xFF);
						stopTimerSchedule();
						byte[] msgs=new byte[datas.length-1];
						System.arraycopy(datas, 1, msgs, 0, msgs.length);
						responseDataList.add(msgs);
						Log.e("", "SEQ:"+SEQ);
						

						requestCurrentDatas=new byte[]{(byte) (SEQ^0xFF)};
						sendRequestTimer();
					}
				}
			}
		});
		

		//UP Check Reverse成功时，返回
		setApduCheckCallback(new ApduCheckCallback<Boolean>() {

			@Override
			public void onSuccess(Object result) {
				// TODO Auto-generated method stub
				if(result!=null && result instanceof Boolean){
					
					if(packagesNumber-1<=SEQ+1){//finish  packagesNumber=1 or others
						stopTimerSchedule();
						Log.e("", "Finish:Apdu Back...");
						u2fCmdStat=null;
						if(getOnGattLeCallback()!=null){
							getOnGattLeCallback().onApduback(encodingResponse(responseDataList));
						}
					}else{
						if(!(Boolean) result){
							Log.e("", "waiting for next Apdu Back...");
						}
					}
				}
			}
		});
		
	}
	
	/**
	 * 广播监听
	 */
	private final BLeBroadcastReceiver mBLeReceiver=new BLeBroadcastReceiver();
	public void registerLeReceiver(Context context) {
		IntentFilter filter = new IntentFilter(); 
		filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED); 
		context.registerReceiver(mBLeReceiver, filter); 
		Log.i("","register bluetooth Le receiver");
	}
	
	public void unregisterLeReceiver(Context context){
		context.unregisterReceiver(mBLeReceiver);
		Log.i("","unregister bluetooth Le receiver");
	}
	 
	
	/**
     * 判断是否打开蓝牙
     * @return
     */
    public boolean isBluetoothLeOpen() {
    	if(mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()){
    		return true;
    	}
    	return false;
	}
   
    /**
     * 打开蓝牙开关
     */
	public void openBluetoothLe(){
		if(mBluetoothAdapter != null && !mBluetoothAdapter.isEnabled()){
			mBluetoothAdapter.enable();
    	}
	}
	
    
    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }
    /**
     * Complete shutdown of connection.
     * Disconnect, close, and flush the write queue for any unprocessed ble operations.
     */
    public void shutdownConnection() {
		if(mBluetoothGatt == null){
		    return;
		}
		mBluetoothGatt.disconnect();
		try {Thread.sleep(20);} catch (InterruptedException e) { e.printStackTrace();}
    };
    /*****************************************************************************/

    /**
     * 连接设备
     * @param device BluetoothDevice
     * @return true if connection attempt was initiated successfully.
     */
    public boolean connectLeDevice(BluetoothDevice device) {
    	//if bleAdapter is't enable,do not connect and stop Scan
        if (mBluetoothAdapter == null || device == null 
        		|| (mBluetoothAdapter!=null && !mBluetoothAdapter.isEnabled())) {
        	Log.i("", "Unable to connect.");
            return false;
        }
        if(mGattCallback==null){
        	mGattCallback = new LeGattCallback(ILeController.this);
        }
        
        mBluetoothGatt = 
        		device.connectGatt(activity, false, mGattCallback);
        if(mBluetoothGatt!=null){
        	isConnectingNotClearScans=true;
        }else{
        	return false;
        }
        return true;
    }
    
    public void disconnect(){
    	if(mBluetoothGatt == null){
		    return;
		}
		mBluetoothGatt.disconnect();
		try {Thread.sleep(20);} catch (InterruptedException e) { e.printStackTrace();}
    }
    
    /***********************************************************************/
    /**
     * enable notification/indication
     * @param gattService
     * @param en
     * @param isEnable
     */
    private void changeNotificationStatus(final BluetoothGattService gattService,final boolean isEnable,final ENABLE en) {
//		writeQueue.queueRunnable(
//			new Runnable() { 
//			    @Override
//			    public void run() {
			    	try {
						if(mBluetoothGatt==null || en==ENABLE.NONE){
							Log.i(TAG, "mBluetoothGatt==null || en==ENABLE.NONE");
							return;
						}
						UUID CharacUUID= 
//								(en==ENABLE.NOTIFY ? 
										u2fStatus_NOTI_CHARAC_UUID
//										:u2fStatus_INDICATE_CHARAC_UUID)
										;
						BluetoothGattCharacteristic dataCharacteristic = gattService.getCharacteristic(CharacUUID);
						if(mBluetoothGatt.setCharacteristicNotification(dataCharacteristic, true)){
							Log.i("", "The notification status was changed.");
						}else{
							Log.i("", "Failed to set the notification status.");
						}

						BluetoothGattDescriptor config = dataCharacteristic.getDescriptor(CCC);
						if(config != null){
							Log.i("","Unable to get config descriptor.");
						}

						byte[] configValue = isEnable ? (en==ENABLE.NOTIFY ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.ENABLE_INDICATION_VALUE) : BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE;
						config.setValue(configValue);

						if(mBluetoothGatt.writeDescriptor(config)){
							Log.i("", "Initiated a write to descriptor.");
						} else {
							Log.i("", "Unable to initiate write.");
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
//			    } 
//			}
//		);
    }

    private ENABLE enableNI=ENABLE.NOTIFY;
    private boolean isNI=false;
    public void setNotification(final BluetoothGattService gattService,boolean isEnable,ENABLE enable){
    	this.enableNI=enable;
    	isNI=(this.enableNI==ENABLE.BOTH ? true:false);
    	
    	if(this.enableNI==ENABLE.NONE){
    		
    	}else if(this.enableNI==ENABLE.NOTIFY || this.enableNI==ENABLE.BOTH){
    		changeNotificationStatus(gattService, isEnable,ENABLE.NOTIFY);
    	}else if(this.enableNI==ENABLE.INDICATE){
    		changeNotificationStatus(gattService, isEnable,ENABLE.INDICATE);
    	}
    }
    
    /***********************************************************************/

    public void onDestroy() {

		// Probably not necessary since onPause stops the scan.
		if(mBluetoothAdapter != null){
		    mBluetoothAdapter.stopLeScan(mLeScanCallback);
		    mBluetoothAdapter = null;
		}
		unregisterLeReceiver(activity);
		shutdownConnection();
    }
    
    /*****************************************************************/
    
	private void setLeScanCallback() {
		if(mLeScanCallback==null){
			mLeScanCallback = new LeScanCallback() {
			    public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
//			    	Log.e("", ""+(device!=null?device.getName():""));
					if(isMatchFilters(device.getName())){
//						Log.i("", ""+device.getName()+" "+device.getAddress());
						Log.i("", ""+ByteStringUtils.Byte2hexString(scanRecord, false));
						add2Advertisers(new ScanEntity(device, rssi, scanRecord, 0));
						
						//if not exist,add into scans and then if exist ,update it
						updateScans(device, rssi, scanRecord);
						
						if(mOnGattLeCallback!=null){
							mOnGattLeCallback.onScanResult(device, rssi, scanRecord);
						}
					}
			    }
			};
		}
	}
	
	public void add2Advertisers(ScanEntity device){
		if(advertisers!=null){
			advertisers.add(device);
		}
	}
	public void setLeScanCallback(LeScanCallback mLeScanCallback){
		this.mLeScanCallback=mLeScanCallback;
	}
	
	/************************************************************/
	/**
     * the flag of current  bluetooth device connected or disconnected  
     */
	public boolean connectState=false;
    /**
     * Current connected or disconnected or operation of a bluetooth device
     */
    public ScanEntity mCurrentEntity=null;
    /**
     * 断开后是否需要自动重连
     */
    public boolean isAutoReconnect=false;
    /**
     * 正在连接设备，不再清空扫描到的设备集合
     */
    protected boolean isConnectingNotClearScans=false;
//    /**
//     * 是否配对绑定、是否上电、是否复位、是否下电
//     */
//    public boolean isU2FBound=false,isU2FPowOn=false,isU2FPowOff=false,isU2FReset=false;

	public void removeScans(BluetoothGatt gatt){
		int index=-1;
		if(gatt!=null){
			index=indexScans(gatt.getDevice());
		}
		synchronized (workingDevices) {
			if(index!=-1 && workingDevices.size()>0 && workingDevices.size()>index){
				workingDevices.remove(index);
				Log.i("removeOfScans", "---->"+workingDevices.size());
			}
		}
		
	}
	/**
	 * 
	 * @param device
	 * @return
	 */
	public int indexScans(BluetoothDevice device){
		int index=-1;
		for(int i=0;i<workingDevices.size();i++){
			ScanEntity entity=workingDevices.get(i);
			if(entity.getDevice()!=null && !TextUtils.isEmpty(entity.getDevice().getAddress())
					&& device!=null && !TextUtils.isEmpty(device.getAddress())){
				if(entity.getDevice().getAddress().equals(device.getAddress())){
					index=i;
					break;
				}
			}
		}
		return index;
	}
	/**
	 * 存在，则update；不存在，则add
	 * @param device
	 * @param rssi
	 * @param scanRecord
	 */
	public void updateScans(BluetoothDevice device,int rssi,byte[] scanRecord){
		int index=-1;
		index=indexScans(device);
		
		synchronized (workingDevices) {
			if(index!=-1 && workingDevices.size()>index){
				workingDevices.get(index).setRssi(rssi);
				workingDevices.get(index).setScanRecord(scanRecord);
				Log.i("updateOfScans", "index:"+index+"---->"+workingDevices.size());
			}else{
				workingDevices.add(new ScanEntity(device, rssi, scanRecord,0));
				Log.i("updateOfScans", "add");
			}
			
		}
	}
	/*****************************************************************************/
    private ScheduledFuture<?> handle;
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private Boolean firstRun = true;
    public static final int TIME_OUT_PERIOD = 6000;
    private int PERIOD = TIME_OUT_PERIOD / 2;
    
	/**
     * 所有正在工作的设备，包括连接上，正在连接，正在广播
     */
    public ArrayList<ScanEntity> workingDevices=new ArrayList<ScanEntity>();
    /**
     * the devices scanned during period
     */
    public Set<ScanEntity> advertisers = Collections.synchronizedSet(new HashSet<ScanEntity>());
    
    final Runnable startScanRunnable = new Runnable(){
	    public void run() {
			try {
				Log.e("", "startScanRunnable");
			    if(firstRun){
			    	firstRun = false;
			    	mBluetoothAdapter.startLeScan(mLeScanCallback); //TODO: check return value
			    }
			    else {
			    	if(mOnGattLeCallback!=null){
			    		mOnGattLeCallback.onScanPeriodResults(workingDevices);
			    	}
			    	if(!isConnectingNotClearScans){
			    		workingDevices.clear();
			    	}
			    	advertisers = Collections.synchronizedSet(new HashSet<ScanEntity>());
			    	mBluetoothAdapter.stopLeScan(mLeScanCallback);
			    	mBluetoothAdapter.startLeScan(mLeScanCallback);
			    }
			} catch (Exception e) {
			    //NB: We do infamous Catch-em-all exception handling because if we don't catch the
			    // exception it will be silently ignored by the scheduler.
			    Log.e(TAG, "", e);
			}
	    };
	};
	
    public boolean isBluetoothLeScanInit(){
    	if(isBluetoothLeOpen() && mLeScanCallback!=null){
    		return true;
    	}
    	return false;
    }
    
    public void startLeScan(){
		if(scanType == ScanType.CONTINUOUS){
			Log.e("", "ScanType.CONTINUOUS");
			mBluetoothAdapter.startLeScan(mLeScanCallback);
		    return;
		}
		firstRun = true;
		
		// restartScanRunnable will be run on the thread that calls scheduleAtFixedRate, 
		// which is why we want to create a new thread just for that call.
		new Thread(new Runnable(){
		    public void run() {
		    	handle = scheduler.scheduleAtFixedRate(startScanRunnable, PERIOD, PERIOD, TimeUnit.MILLISECONDS);
		    }
		}).start();
    }

    public void stopLeScan() {
		if(scanType == ScanType.CONTINUOUS){
			Log.e("", "ScanType.CONTINUOUS");
			mBluetoothAdapter.stopLeScan(mLeScanCallback); //Must be same instance that started the scan
		    return;
		}
		
		boolean mayInterruptIfRunning = true;
		if(handle!=null && !handle.isCancelled()){
			handle.cancel(mayInterruptIfRunning);
		}
		mBluetoothAdapter.stopLeScan(mLeScanCallback);
    }

    private Timer mScanTimer=null;
    private boolean scanOrnot=false;
    public void startScanLe(){
		if(scanType == ScanType.CONTINUOUS){
			Log.e("", "ScanType.CONTINUOUS");
			mBluetoothAdapter.startLeScan(mLeScanCallback);
		    return;
		}
		firstRun = true;
		if(mScanTimer==null){
			mScanTimer=new Timer(); 
		}
		mScanTimer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					Log.e("", "startScanLe()");
					scanOrnot=true;//
				    if(firstRun){
				    	firstRun = false;
				    	mBluetoothAdapter.startLeScan(mLeScanCallback); //TODO: check return value
				    }
				    else {
				    	if(mOnGattLeCallback!=null){
				    		mOnGattLeCallback.onScanPeriodResults(workingDevices);
				    	}
				    	if(!isConnectingNotClearScans){
				    		workingDevices.clear();
				    	}
				    	advertisers = Collections.synchronizedSet(new HashSet<ScanEntity>());
				    	
				    	mBluetoothAdapter.stopLeScan(mLeScanCallback);
						if(mBluetoothAdapter!=null && scanOrnot){
							mBluetoothAdapter.startLeScan(mLeScanCallback);
							if(!scanOrnot){
								mBluetoothAdapter.stopLeScan(mLeScanCallback);
							}
						}
				    }
				} catch (Exception e) {
				    Log.e(TAG, "", e);
				}
			}
		}, PERIOD, PERIOD);
    }

    public void stopScanLe() {
		if(scanType == ScanType.CONTINUOUS){
			Log.e("", "ScanType.CONTINUOUS");
			mBluetoothAdapter.stopLeScan(mLeScanCallback); //Must be same instance that started the scan
		    return;
		}
		if(mScanTimer!=null){	
	    	mScanTimer.cancel();
		    mScanTimer=null;
	    }	
	    if(mBluetoothAdapter!=null){
	    	mBluetoothAdapter.stopLeScan(mLeScanCallback);
	        scanOrnot=false;
		}
    }
    

    public int getScanPeriod() {
		return PERIOD;
	}
    /**
     * 设置扫描周期
     * @param scanperiod_millis 
     */
	public void setScanPeriod(int scanperiod_millis) {
		if(scanperiod_millis<2000){
			scanperiod_millis=2000;
		}
		PERIOD = scanperiod_millis;
	}
	
   
    /*****************************UUID************************************/
    /**
     * service
     */
    public UUID u2f_SERV_UUID						=UUID.fromString("4649444F-2E55-3246-2E42-542E4C452E51");
    /**
     * write-only
     */
    public UUID u2fControlPoint_CHARAC_UUID			=UUID.fromString("75324350-DC65-4690-AE7F-9D54E0059C86");
    /**
     * read
     */
    public UUID u2fControlPointLength_CHARAC_UUID	=UUID.fromString("7532434C-BE86-4BA8-87BC-23733DDDC61E");
    /**
     * noti-only
     */
    public UUID u2fStatus_NOTI_CHARAC_UUID			=UUID.fromString("75325354-E94E-430C-A438-A8ED46016D93");
    
    
    
    
//    public UUID u2fStatus_INDICATE_CHARAC_UUID		=UUID.fromString("75325354-E94E-430C-A438-A8ED46016D93");//???
//    /**
//     * read
//     */
//    public UUID u2fServiceRevision_CHARAC_UUID		=UUID.fromString("..282A..");
    
    /*******************************UUID End*****************************************/
	
	/*******************************mainHandler数据集中处理******************************/
	
	public static final int U2F_RESEND=20,U2F_SUCCESS=21,U2F_ERROR=22,U2F_FAILED=23,
			U2F_ATR=24;
    /**
     * 重发次数
     */
	protected int resendCounter=0;
    protected Timer mTimer = null;
    /**
     * 数据集中处理
     */
    public Handler mainHandler=new Handler(Looper.getMainLooper()){
    	public void handleMessage(Message msg) {
    		switch(msg.what){
    		case U2F_RESEND:
    			if(resendCounter++<3){
    				write(requestCurrentDatas);
    			}else{
    				mainHandler.sendEmptyMessage(U2F_ERROR);
    			}
    			break;
    		case U2F_SUCCESS:
    			
    			successBack(msg);
    			
    			recoveryCmdDownParams();
    			
    			break;
    		case U2F_ERROR://传输失败，构造一个上层的ERROR（0xBF）逻辑帧返回
    			
				if(getCmdCallback()!=null){
	    			getCmdCallback().onError(new byte[]{(byte) 0xBF,0x00,0x00}, 0);
	    		}
				recoveryCmdDownParams();
    			break;
    		}
    	}

		public void successBack(Message msg) {
			byte[] datas=null;
			switch(u2fCmdStat){
			case MSG:
			case BF_POWER_ON:
			case BF_POWER_OFF:
			case BF_RESET:
				if(getCmdCallback()!=null){
	    			getCmdCallback().onSuccess(true);
	    		}
				break;
			case PING_UP:
			case MSG_UP:
			case BF_AUPD_UP:
				datas=(byte[])msg.obj;
				if(getOnGattLeCallback()!=null){
					getOnGattLeCallback().onApduback(datas);
	    		}
				break;
				default:
					break;
			}
		};
    };
    /*************************************************************/
    
    /**
     * 当前正在执行的指令数据
     */
    public byte[] requestCurrentDatas=null;
    
    public U2F_CMD_STAT u2fCmdStat=null;
    public enum U2F_CMD_STAT{
    	PING,PING_UP,MSG,MSG_UP,
    	BF_PAIRING,BF_POWER_ON,
    	BF_POWER_OFF,BF_RESET,
    	BF_DATA_TRANSFER
    	,BF_AUPD_UP
    }
    
    public void recoveryCmdDownParams(){
    	stopTimerSchedule();
		u2fCmdStat=null;
		this.requestDataList.clear();
		this.dataReqLen=0;
		this.HiLEN=0;
		this.LoLEN=0;
		this.SEQ=0;
		this.currentIndex=0;
		
		this.packagesNumber=0;
		
		isFirstPackage=true;
		
		this.responseDataList.clear();
		this.responseDatas=null;
    }
    /**
     * 首字节必须为0x81,长度必须大于等于3
     * @param datas:完整的一天指令
     * @param callback
     * 
     * 成功后直接返回数据
     */
    public void ping(byte[] datas,CmdCallback<byte[]> callback){
    	setCmdCallback(callback);
    	if(datas!=null && datas.length>=3 && datas.length<=20 && ((datas[0]&0xFF)==0x81)){
    		if(datas.length<=maxMainPackageLen+3){
    			CMDId=0x81;
    			u2fCmdStat=U2F_CMD_STAT.PING;
    			
        		this.dataReqLen=(short) (datas.length-3);
        		this.HiLEN=ByteStringUtils.hiUint16(dataReqLen);
        		this.LoLEN=ByteStringUtils.loUint16(dataReqLen);
    			requestCurrentDatas=new byte[datas.length];
    			requestCurrentDatas[0]=(byte) 0x81;
    			requestCurrentDatas[1]=this.HiLEN ;
    			requestCurrentDatas[2]=this.LoLEN;
    			System.arraycopy(datas, 0, requestCurrentDatas, 0, datas.length);
    			setApduDownCallback(new ApduDownCallback<byte[]>() {

					@Override
					public void onDownSuccess(byte[] result,boolean isFirstPackage) {
						// TODO Auto-generated method stub
						stopTimerSchedule();
		    			u2fCmdStat=null;
						if(result!=null ){
							byte[] datas=(byte[]) result;
							if(getCmdCallback()!=null && isFirstPackage){
								getCmdCallback().onSuccess(datas);
							}
						}
					}

				});
    			sendRequestTimer();
    		}else{//return error logicframe
    			mainHandler.sendEmptyMessage(U2F_ERROR);
    		}
    	}else{
    		mainHandler.sendEmptyMessage(U2F_ERROR);
    	}
    }
    /**
     * 首字节必须为0x83,长度必须大于等于3
     * @param datas
     * @param callback
     */
    public void msgapdu(byte[] datas,CmdCallback<Boolean> callback){
    	setCmdCallback(callback);
    	if(datas!=null && datas.length>=3 && ((datas[0]&0xFF)==0x83)){
    		CMDId=0x83;
			u2fCmdStat=U2F_CMD_STAT.MSG;
			initDecodingRequest(datas);
			decodingRequest(requestDatas);
			
			requestCurrentDatas=requestDataList.get(0);
			
			setApduDownCallback(new ApduDownCallback<byte[]>() {

				@Override
				public void onDownSuccess(byte[] result,boolean isFirstPackage) {
					// TODO Auto-generated method stub
	    			
					if(result!=null){
						byte[] datas=result;
						
						if(isFirstPackage){//首包成功，判断是否还需要发次包
							SEQ=0;
							currentIndex=0;
							if(requestDataList.size()>1){//
								Log.e("msgapdu", "Down msgapdu:next package SEQ("+SEQ+")");
								byte[] srcBytes=requestDataList.get(currentIndex+1);
								requestCurrentDatas=new byte[srcBytes.length+1];
								requestCurrentDatas[0]=SEQ;
								System.arraycopy(srcBytes, 0, requestCurrentDatas, 1, srcBytes.length);
								sendRequestTimer();
							}else{//
								Log.e("msgapdu", "write success...");
								mainHandler.sendEmptyMessage(U2F_SUCCESS);
							}
							
						}else{//次包
							Log.e("msgapdu", "SEQ:"+SEQ+" (datas[0]^0xFF):"+((datas[0]^0xFF)&0xFF));
							
							if(SEQ == ((datas[0]^0xFF) &0xFF)){//next
								if(requestDataList.size()-1 > SEQ+1){
									SEQ++;
									if(SEQ>0x7F){
										SEQ=0;
									}
									currentIndex++;
									byte[] srcBytes=requestDataList.get(currentIndex+1);
									requestCurrentDatas=new byte[srcBytes.length+1];
									requestCurrentDatas[0]=SEQ;
									System.arraycopy(srcBytes, 0, requestCurrentDatas, 1, srcBytes.length);
									Log.e("msgapdu", "msgapdu:next package-->SEQ("+SEQ+")");
									sendRequestTimer();
								}else{//
									Log.e("msgapdu", "write success...");
									mainHandler.sendEmptyMessage(U2F_SUCCESS);
								}
							}else{//resend
								Log.e("", "msgapdu:bf or resend");
							}
							
						}
					}
				}
			});
			
			sendRequestTimer();
			
    	}else{
    		mainHandler.sendEmptyMessage(U2F_ERROR);
    	}
    }
	
    public void sendRequestTimer() {
		stopTimerSchedule();
		mTimer=new Timer();
		mTimer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				mainHandler.sendEmptyMessage(U2F_RESEND);
			}
		}, 0, 1500+500);
	}
    /**
     * 首字节必须为0xBF,长度必须大于等于3
     * @param datas
     * @param callback
     */
    public void bfapdu(byte[] datas,CmdCallback<Boolean> callback){
    	setCmdCallback(callback);
    	if(datas!=null && datas.length>=3 && ((datas[0]&0xFF)==0xBF)){
    		CMDId=0xBF;
    		u2fCmdStat=U2F_CMD_STAT.BF_DATA_TRANSFER;
    		initDecodingRequest(datas);
			decodingRequest(requestDatas);
			
			requestCurrentDatas=requestDataList.get(0);
    		
			System.arraycopy(requestDataList.get(0), 0, requestCurrentDatas, 3, requestDataList.get(0).length);
			
			setApduDownCallback(new ApduDownCallback<byte[]>() {

				@Override
				public void onDownSuccess(byte[] result,boolean isFirstPackage) {
					// TODO Auto-generated method stub
	    			
					if(result!=null){
						byte[] datas=result;
						
						if(isFirstPackage){//首包成功，判断是否还需要发次包
							Log.e("bfapdu", "首包成功");
							SEQ=0;
							currentIndex=0;
							if(requestDataList.size()>1){//
								byte[] srcBytes=requestDataList.get(currentIndex+1);
								requestCurrentDatas=new byte[srcBytes.length+1];
								requestCurrentDatas[0]=SEQ;
								System.arraycopy(srcBytes, 0, requestCurrentDatas, 1, srcBytes.length);
								sendRequestTimer();
							}else{//
								Log.e("bfapdu", "write success...");
								mainHandler.sendEmptyMessage(U2F_SUCCESS);
							}
							
						}else{//次包
							Log.e("bfapdu", "SEQ:"+SEQ+" (datas[0]^0xFF):"+((datas[0]^0xFF) &0xFF));
							
							if(SEQ == ((datas[0]^0xFF) &0xFF)){//next
								if(requestDataList.size()-1 > SEQ+1){
									SEQ++;
									if(SEQ>0x7F){
										SEQ=0;
									}
									currentIndex++;
									byte[] srcBytes=requestDataList.get(currentIndex+1);
									requestCurrentDatas=new byte[srcBytes.length+1];
									requestCurrentDatas[0]=SEQ;
									System.arraycopy(srcBytes, 0, requestCurrentDatas, 1, srcBytes.length);
									Log.e("bfapdu", "bfapdu:next package-->SEQ("+SEQ+")");
									sendRequestTimer();
								}else{//
									Log.e("mbfapdu", "write success...");
									mainHandler.sendEmptyMessage(U2F_SUCCESS);
								}
							}else{//resend
								Log.e("bfapdu", "bfapdu:bf or resend");
							}
							
						}
					}
				}
			});
			
			sendRequestTimer();
			
    	}else{
    		mainHandler.sendEmptyMessage(U2F_ERROR);
    	}
    }
    /**
     * @param datas:byte[4] 长度为4的配对码
     */
    public void pairing(byte[] datas,CmdCallback<Boolean> callback){
    	setCmdCallback(callback);
    	if(datas!=null && datas.length==4){
    		CMDId=0xBF;
        	u2fCmdStat=U2F_CMD_STAT.BF_PAIRING;
        	
        	this.requestDataList.clear();
    		this.dataReqLen=4;
    		this.HiLEN=0;
    		this.LoLEN=4;
    		requestCurrentDatas=new byte[]{(byte) 0xBF,this.HiLEN,this.LoLEN,datas[0],datas[1],datas[2],datas[3]};
    		isFirstPackage=true;
    		setApduDownCallback(new ApduDownCallback<byte[]>() {

				@Override
				public void onDownSuccess(byte[] result, boolean isFirstPackage) {
					if(isFirstPackage){
						Log.e("", "pairing Success");
						mainHandler.sendEmptyMessage(U2F_SUCCESS);
					}
					
				}
			});
    		sendRequestTimer();
    	}else{
    		mainHandler.sendEmptyMessage(U2F_ERROR);
    	}
    	
    }
    
    public void poweron(CmdCallback<byte[]> callback){//成功时，输出N字节代表冷复位ATR
    	setCmdCallback(callback);
    	
    	CMDId=0xBF;
    	u2fCmdStat=U2F_CMD_STAT.BF_POWER_ON;
    	this.requestDataList.clear();
		this.dataReqLen=3;
		this.HiLEN=0;
		this.LoLEN=3;
		requestCurrentDatas=new byte[]{(byte) 0xBF,0x00,0x03,(byte) 0xC3,(byte) 0xC1,(byte) 0xC7};
		
		isFirstPackage=true;
		setApduDownCallback(new ApduDownCallback<byte[]>() {

			@Override
			public void onDownSuccess(byte[] result, boolean isFirstPackage) {
				if(isFirstPackage){
					Log.e("", "Success poweron");
					mainHandler.sendEmptyMessage(U2F_SUCCESS);
				}
				
			}
		});
		sendRequestTimer();
    }
    
    public void reset(CmdCallback<byte[]> callback){//成功时，输出N字节代表热复位ATR
    	setCmdCallback(callback);
    	
    	CMDId=0xBF;
    	u2fCmdStat=U2F_CMD_STAT.BF_RESET;
    	this.requestDataList.clear();
		this.dataReqLen=3;
		this.HiLEN=0;
		this.LoLEN=3;
		requestCurrentDatas=new byte[]{(byte) 0xBF,0x00,0x03,(byte) 0xC3,(byte) 0xC2,(byte) 0xC7};
		
		isFirstPackage=true;
		setApduDownCallback(new ApduDownCallback<byte[]>() {

			@Override
			public void onDownSuccess(byte[] result, boolean isFirstPackage) {
				if(isFirstPackage){
					Log.e("", "Success reset");
					mainHandler.sendEmptyMessage(U2F_SUCCESS);
				}
				
			}
		});
		
		sendRequestTimer();
    }
    
    public void poweroff(CmdCallback<byte[]> callback){//成功时，输出2字节数据0000
    	setCmdCallback(callback);
    	requestCurrentDatas=new byte[]{(byte) 0xBF,0x00,0x03,(byte) 0xC5,(byte) 0xC1,(byte) 0xC3};
    	u2fCmdStat=U2F_CMD_STAT.BF_POWER_OFF;
    	this.requestDataList.clear();
		this.dataReqLen=3;
		this.HiLEN=0;
		this.LoLEN=3;
		
		isFirstPackage=true;
		setApduDownCallback(new ApduDownCallback<byte[]>() {

			@Override
			public void onDownSuccess(byte[] result, boolean isFirstPackage) {
				if(isFirstPackage){
					Log.e("", "poweroff Success");
					mainHandler.sendEmptyMessage(U2F_SUCCESS);
				}
				
			}
		});
		
		sendRequestTimer();
    }
    
    public void stopTimerSchedule(){
    	if(mTimer!=null){
			mTimer.cancel();
			mTimer=null;
		}
    	resendCounter=0;
    }

    public void write(byte[] datas){
    	BluetoothGatt gatt=mBluetoothGatt;
		BluetoothGattCharacteristic charac = gatt.getService(u2f_SERV_UUID).getCharacteristic(u2fControlPoint_CHARAC_UUID);
		charac.setValue(datas);
		boolean isTrue=gatt.writeCharacteristic(charac);
		Log.i("", "write():"+isTrue+" "+ByteStringUtils.Byte2hexString(requestCurrentDatas));
		if(isTrue==false){
			resendCounter-=1;
		}else{
			
			if(u2fCmdStat!=null && (u2fCmdStat==U2F_CMD_STAT.BF_AUPD_UP || u2fCmdStat==U2F_CMD_STAT.MSG_UP || u2fCmdStat==U2F_CMD_STAT.PING_UP)){
				if(getApduCheckCallback()!=null && (datas !=null && datas.length==1)){
					getApduCheckCallback().onSuccess(true);
				}
			}
		}
    }
	/*****************************CMD************************************/
    
    /**
     * 16进制请求字符串转换成的字节数组
     */
    public byte[] requestDatas=null;
    
    /**
     * requestDatas拆分主包、次包后得到的字节数组集合
     */
	public final ArrayList<byte[]> requestDataList=new ArrayList<byte[]>();
	/**
	 * 命令类型
	 */
	private int CMDId=0;
	/**
	 * 主包数据长度的高低8位
	 */
	private byte HiLEN=0,LoLEN=0;
	/**
	 * dataReqLen:主包数据长度
	 * currentIndex:requestDataList执行到哪里的下标
	 */
	private short dataReqLen=0,currentIndex=0;
	/**
	 * 包数：主包+次包 数量
	 * 可以通过主包数据长度dataReqLen计算出来
	 */
	private short packagesNumber=0;
	/**
	 * 
	 * 次包序号：数据包序列0x00...0x7f(高位总清除)
	 */
	private byte SEQ=0;
	private boolean isFirstPackage=true;
	/**
	 * 次包数据最大长度
	 */
	public static final short maxMainPackageLen=17,maxSubPackageLen=19;
	
	/**
	 * 请求相关变量初始化
	 * @param requestHexString
	 */
	public void initDecodingRequest(byte[] requestDatas){
		this.requestDatas=requestDatas;
		if(this.requestDatas!=null){
			this.SEQ=0;
			this.currentIndex=0;
			this.requestDataList.clear();
			this.dataReqLen=(short) (this.requestDatas.length-3);
			this.packagesNumber=(short) splitPackage(this.requestDatas.length-3);
			this.HiLEN=ByteStringUtils.hiUint16(this.dataReqLen);
			this.LoLEN=ByteStringUtils.loUint16(this.dataReqLen);
		}else{
			this.SEQ=0;
			this.currentIndex=0;
			this.requestDataList.clear();
			this.dataReqLen=0;
			this.packagesNumber=0;
			this.HiLEN=0;
			this.LoLEN=0;
		}
	}
	/**
	 * 拆请求包
	 * @param requestDatas==>requestDataList
	 */
	public void decodingRequest(byte[] requestDatas){
		requestDataList.clear();
		if(requestDatas!=null && requestDatas.length > 0){
			
			if(requestDatas.length<=maxMainPackageLen+3){//首包
				requestDataList.add(requestDatas);
			}else{
				byte[] bytes=null;
				
				bytes=new byte[maxMainPackageLen+3];
				System.arraycopy(requestDatas, 0, bytes, 0, bytes.length);
				requestDataList.add(bytes);//首包
				
				ArrayList<Byte> byteList=new ArrayList<Byte>();
				for(int i=maxMainPackageLen+3;i< requestDatas.length;i++){
					if(byteList.size() < maxSubPackageLen ){
						byteList.add(requestDatas[i]);
					}else{
						requestDataList.add(ByteStringUtils.byteList2ByteArray(byteList));
						byteList=new ArrayList<Byte>();
						
						byteList.add(requestDatas[i]);
					}
				}
				
				if(requestDataList.size()<packagesNumber){
					requestDataList.add(ByteStringUtils.byteList2ByteArray(byteList));
				}
			}
		}
	}
	/**
	 * -3
	 * @param requestDatasLen
	 * @return
	 */
	public int splitPackage(int requestDatasLen) {
		int listsize=1;//首包
		if(requestDatasLen<=maxMainPackageLen){
			return 1;
		}
		listsize+=(requestDatasLen-maxMainPackageLen)%maxSubPackageLen!=0 ? 
				((requestDatasLen-maxMainPackageLen)/maxSubPackageLen+1)
				: (requestDatasLen-maxMainPackageLen)/maxSubPackageLen;
		return listsize;
	}
	
	
	
	/**
	 * 响应数据集合
	 */
	public final ArrayList<byte[]> responseDataList=new ArrayList<byte[]>();
	/**
	 * 由响应数据集合===>响应字节数组
	 */
	public byte[] responseDatas=null;
	/**
	 * 拼包
	 * @param byteArrayList 响应数据集合
	 * @return 响应字节数组
	 */
	public byte[] encodingResponse(ArrayList<byte[]> byteArrayList){
		responseDatas=null;
		if(byteArrayList!=null && byteArrayList.size()>0){
			int size=byteArrayList.size();
			int byteLength=0;
			if(size==1){
				byteLength=byteArrayList.get(size-1).length;
			}else if(size==2){
				byteLength=maxMainPackageLen+3+byteArrayList.get(size-1).length;
			}else{
				byteLength=maxMainPackageLen+3+(size-2)*maxSubPackageLen+byteArrayList.get(size-1).length;
			}
			
			responseDatas=new byte[byteLength];
			
			int dstPos=0;
			for(int i=0;i<size;i++){
				byte[] bytes=byteArrayList.get(i);
				System.arraycopy(bytes, 0, responseDatas, dstPos, bytes.length);
				dstPos+=bytes.length;
			}
		}
		return responseDatas;
	}
	
	/****************************回调接口定义*************************************/

    public interface OnGattLeCallback{
        public abstract void onScanResult(BluetoothDevice device, int rssi, byte[] scanRecord);
        public abstract <T> void onScanPeriodResults(ArrayList<T> results);
        public abstract void onConnectionStateChange(BluetoothGatt gatt,int state,boolean isConnect);
        public abstract void onApduback(byte[] results);//msg_up/bf_up
    }
    
    private OnGattLeCallback mOnGattLeCallback;
    /**
	 * 获取蓝牙回调处理监听类
	 * @return
	 */
	public OnGattLeCallback getOnGattLeCallback() {
		return mOnGattLeCallback;
	}
	/**
	 * 设置蓝牙回调处理监听
	 * @param mOnGattLeCallback OnGattLeCallback
	 */
	public void setOnGattLeCallback(OnGattLeCallback mOnGattLeCallback) {
		this.mOnGattLeCallback = mOnGattLeCallback;
	}
	
    
	public interface ApduCheckCallback<T>{
    	void onSuccess(Object result);
    }
    ApduCheckCallback<?> apduCheckCallback;
    
	public ApduCheckCallback<?> getApduCheckCallback() {
		return apduCheckCallback;
	}
	public void setApduCheckCallback(ApduCheckCallback<?> apduCheckCallback) {
		this.apduCheckCallback = apduCheckCallback;
	}
	
	public interface ApduUpCallback<T>{
    	void onUpSuccess(byte[] result,boolean isFirstPackage);
    }
    ApduUpCallback<?> apduUpCallback;
    
	public ApduUpCallback<?> getApduUpCallback() {
		return apduUpCallback;
	}
	public void setApduUpCallback(ApduUpCallback<?> apduUpCallback) {
		this.apduUpCallback = apduUpCallback;
	}
	
	public interface ApduDownCallback<T>{
    	void onDownSuccess(byte[] result,boolean isFirstPackage);
    }
    ApduDownCallback<?> apduDownCallback;
    
	public ApduDownCallback<?> getApduDownCallback() {
		return apduDownCallback;
	}
	public void setApduDownCallback(ApduDownCallback<?> apduDownCallback) {
		this.apduDownCallback = apduDownCallback;
	}

	/**
	 * 回调类CmdCallback<T>
	 *
	 * @param <T>
	 */
	public interface CmdCallback<T>{//interface
		 void onSuccess(Object result);
		 void onError(byte[] ex,int errorCode);
	}
	public CmdCallback<?> cmdCallback;
	
	public CmdCallback<?> getCmdCallback() {
		return cmdCallback;
	}
	public void setCmdCallback(
			CmdCallback<?> cmdCallback) {
		this.cmdCallback = cmdCallback;
	}
	/******************************OAD***********************************/
	
	/******************************OAD End********************************/
}
