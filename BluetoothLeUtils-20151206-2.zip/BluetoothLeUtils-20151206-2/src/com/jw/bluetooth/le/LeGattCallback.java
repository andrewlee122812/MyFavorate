package com.jw.bluetooth.le;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothProfile;
import android.util.Log;

/**
 * A couple of hiccups that don't come up in the documentation:
 * 
 * If an exception is thrown from one of your callback methods,
 * it will be caught with catch-all exception handling in BluetoothGatt and logged 
 * with priority warning.
 * 
 * This is unfortunate because you do not get a stacktrace, and because log messages
 * at priority warning are easily overlooked. To compensate for this we
 * do our own exception handling and print the stack traces.
 */
public class LeGattCallback extends BluetoothGattCallback {
    protected static final String TAG = "LeCallback";
    private ILeController mLeController;
    public LeGattCallback(ILeController mLeController){
    	this.mLeController=mLeController;
    }
    
    @Override
    public void onConnectionStateChange(final BluetoothGatt gatt, final int status, final int newState) {
		try {
			Log.w(TAG, "status:"+status+" newState:"+newState);
            if (newState == BluetoothProfile.STATE_CONNECTED && status==BluetoothGatt.GATT_SUCCESS) {
            	
            	if(mLeController.mLeGattListener!=null)
            		mLeController.mLeGattListener.onConnect(gatt,true);
                
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status!=BluetoothGatt.GATT_SUCCESS) {
            	if(status!=BluetoothGatt.GATT_SUCCESS){
            		Log.i(TAG, gatt.getDevice().getName()+"--"+gatt.getDevice().getAddress()+", status:"+status);
            	}else{
            		Log.i(TAG, gatt.getDevice().getName()+"--"+gatt.getDevice().getAddress()+" disconnected");
            	}
            	if(mLeController.mLeGattListener!=null)
            		mLeController.mLeGattListener.onConnect(gatt,false);
            }
		} catch (Exception e) {
		    e.printStackTrace();
		}
    }

    /**
     * NB: On the first service discovery between a server-client pair the discovery might take several seconds.
     * It has been observed to take 8 seconds.
     * But on subsequent discovery calls, the client will have the services cached and it will take milliseconds.
     * */
    @Override
    public void onServicesDiscovered(final BluetoothGatt gatt, int status) {
		try {
			if(mLeController.mLeGattListener!=null)
				mLeController.mLeGattListener.onServicesDiscovered(gatt, status == BluetoothGatt.GATT_SUCCESS);
		} catch (Exception e) {
		    Log.e(TAG, "", e);
		}
    }


    @Override
    public void onDescriptorRead(BluetoothGatt gatt,
    		BluetoothGattDescriptor descriptor, int status) {
    	super.onDescriptorRead(gatt, descriptor, status);
    }
    
    @Override
    public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
		try {
			if(mLeController.mLeGattListener!=null)
				mLeController.mLeGattListener.onDescriptorWrite(gatt, descriptor, status == BluetoothGatt.GATT_SUCCESS);
		} catch (Exception e) {
		    Log.e(TAG, "", e);
		}
    }
    
    @Override
    public void onCharacteristicChanged(final BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic) {
		try {
			if(mLeController.mLeGattListener!=null)
				mLeController.mLeGattListener.onCharacteristicChanged(gatt, characteristic);
		} catch (Exception e) {
		    Log.e(TAG, "", e);
		}
    }

    @Override
    public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
    	try {
    		if(mLeController.mLeGattListener!=null)
    			mLeController.mLeGattListener.onCharacteristicRead(gatt, characteristic, status == BluetoothGatt.GATT_SUCCESS);
			if (status == BluetoothGatt.GATT_SUCCESS) {
	        	Log.i(TAG, "onCharacteristicRead ：read charcteristic success");
	        	Log.i(TAG, "chara UUID="+characteristic.getUuid());
	        	Log.i(TAG, "chara descriptor="+characteristic.getDescriptor(characteristic.getUuid()).toString());
	        }else{
	        	Log.i(TAG, "status:"+status);
	        }
		} catch (Exception e) {
		    Log.e(TAG, "", e);
		}
    }
    
    @Override
    public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
		try {
			if(mLeController.mLeGattListener!=null)
    			mLeController.mLeGattListener.onCharacteristicWrite(gatt, characteristic, status == BluetoothGatt.GATT_SUCCESS);
			if(status == BluetoothGatt.GATT_SUCCESS){
//        		Log.i(TAG, "write successfully!"+status);
        	}else {
        		Log.i(TAG, "write failed!"+status);
        	}
		} catch (Exception e) {
		    Log.e(TAG, "", e);
		}
    }

}