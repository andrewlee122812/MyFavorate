package com.jw.bluetooth.utils;

import java.util.ArrayList;
import java.util.Locale;

import android.bluetooth.BluetoothDevice;

import com.jw.bluetooth.models.ScanEntity;

public class Tools {
	/**
     * 判断集合sList是否存在device，如果不存在，则添加
     * @param sList ArrayList<ScanDevice>
     * @param device ScanDevice
     * @return
     */
    public static ArrayList<ScanEntity> insert(ArrayList<ScanEntity> sList,ScanEntity device){
    	ArrayList<ScanEntity> aList=new ArrayList<ScanEntity>();
    	if(device!=null){
    		
    		if(sList!=null && sList.size()>0){
    			if(!getBluetoothDevices(sList).contains(device.getDevice())){
    				aList.add(device);
    			}
    			
    			for(ScanEntity sdevice : sList){
    				aList.add(sdevice);
    			}
    		}else{
    			aList.add(device);
    		}
    		
    	}else{
    		aList=sList;
    	}
    	return aList;
    }
    
    /**
	 * 根据参数ArrayList<ScanDevice> sList 获取集合ArrayList<BluetoothDevice>
	 * @param sList ArrayList<ScanDevice>
	 * @return
	 */
	public static ArrayList<BluetoothDevice> getBluetoothDevices(ArrayList<ScanEntity> sList){
    	ArrayList<BluetoothDevice> mBluetoothDeviceList=new ArrayList<BluetoothDevice>();
        for(ScanEntity myLeDevice:sList){
        	if(!mBluetoothDeviceList.contains(myLeDevice.getDevice()))
        		mBluetoothDeviceList.add(myLeDevice.getDevice());
        }
    	return mBluetoothDeviceList;
    }


	public static String[] turnBytesToHexStringArray( byte[] b) {
		String[] sb=null;
		if(b!=null && b.length>0){
			sb=new String[b.length];
	    	
		   for (int i = 0; i < b.length; i++) { 
		     String hex = Integer.toHexString(b[i] & 0xFF); 
		     if (hex.length() == 1) { 
		       hex = '0' + hex; 
		     } 
		     sb[i]=hex.toUpperCase(Locale.getDefault());
		   } 
		}
    	
	   return sb;
    }
	
	public static String turnBytesToHexString(byte[] b){
    	
    	StringBuilder builder=new StringBuilder();
	   for (int i = 0; b!=null && i < b.length; i++) { 
	     String hex = Integer.toHexString(b[i] & 0xFF); 
	     if (hex.length() == 1) { 
	       hex = '0' + hex; 
	     } 
	     builder.append(hex.toUpperCase(Locale.getDefault())+"");
	   } 
	   return builder.toString();
    
	}
}
