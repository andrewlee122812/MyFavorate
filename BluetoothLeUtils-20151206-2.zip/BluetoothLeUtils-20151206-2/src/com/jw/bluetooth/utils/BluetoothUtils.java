package com.jw.bluetooth.utils;

import static android.bluetooth.BluetoothGatt.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import android.util.Log;

public class BluetoothUtils {
	
	/*************************************************************/
	public static final byte GAP_ADTYPE_FLAGS=0x01;   //Discovery Mode  
	public static final byte GAP_ADTYPE_16BIT_MORE=0x02; //Service: More 16-bit UUIDs available  
	   
	public static final byte GAP_ADTYPE_16BIT_COMPLETE=0x03; //Service: Complete list of 16-bit UUIDs  
	public static final byte GAP_ADTYPE_32BIT_MORE=0x04;     //Service: More 32-bit UUIDs available  
	public static final byte GAP_ADTYPE_32BIT_COMPLETE=0x05; //Service: Complete list of 32-bit UUIDs  
	   
	public static final byte GAP_ADTYPE_128BIT_MORE=0x06;  //Service: More 128-bit UUIDs available  
	   
	public static final byte GAP_ADTYPE_128BIT_COMPLETE=0x07;  //Service: Complete list of 128-bit UUIDs  
	public static final byte GAP_ADTYPE_LOCAL_NAME_SHORT=0x08; //Shortened local name  
	    
	public static final byte GAP_ADTYPE_LOCAL_NAME_COMPLETE=0x09; //Complete local name  
	public static final byte GAP_ADTYPE_POWER_LEVEL=0x0A;  //TX Power Level: 0xXX: -127 to +127 dBm  
	   
	public static final byte GAP_ADTYPE_OOB_CLASS_OF_DEVICE=0x0D; //Simple Pairing OOB Tag: Class of device (3 octets)  
	public static final byte GAP_ADTYPE_OOB_SIMPLE_PAIRING_HASHC=0x0E;//Simple Pairing OOB Tag: Simple Pairing Hash C (16 octets)  
	public static final byte GAP_ADTYPE_OOB_SIMPLE_PAIRING_RANDR=0x0F; //Simple Pairing OOB Tag: Simple Pairing Randomizer R (16 octets)  
	public static final byte GAP_ADTYPE_SM_TK=0x10;   //Security Manager TK Value  
	public static final byte GAP_ADTYPE_SM_OOB_FLAG=0x11;  //Secutiry Manager OOB Flags  
	   
	public static final byte GAP_ADTYPE_SLAVE_CONN_INTERVAL_RANGE=0x12;  //Min and Max values of the connection interval  
	public static final byte GAP_ADTYPE_SIGNED_DATA=0x13;  //Signed Data field  
	public static final byte GAP_ADTYPE_SERVICES_LIST_16BIT=0x14;  //Service Solicitation: list of 16-bit Service UUIDs  
	public static final byte GAP_ADTYPE_SERVICES_LIST_128BIT=0x15; //Service Solicitation: list of 128-bit Service UUIDs  
	public static final byte GAP_ADTYPE_SERVICE_DATA=0x16;  //Service Data  
	public static final byte GAP_ADTYPE_APPEARANCE=0x19;  //Appearance  
	public static final int GAP_ADTYPE_MANUFACTURER_SPECIFIC=255;  //Manufacturer Specific Data
	

	/**
	 *   拆分广播包的数据
	 * @param record 以16进制组合的数据集
	 * @return
	 */
	public static ArrayList<ArrayList<String>> splitScanRecode(String record){
		ArrayList<ArrayList<String>> list_liststr=new ArrayList<ArrayList<String>>();
		ArrayList<String> list=new ArrayList<String>();
		boolean sumCount=false;
		
		String[] records=record.split(" ");
		int count=Integer.parseInt(records[0],16);
		
		for(int i=0;i<records.length;i++){
			if(sumCount){
				sumCount=false;
				count=count+Integer.parseInt(records[i],16)+1;
			}
			if(i==count){
//				if(Integer.parseInt(records[i],16)==0){break;}
				list.add(records[i]);
				sumCount=true;
				list_liststr.add(list);
				list=new ArrayList<String>();
				
			}else{
				list.add(records[i]);				
			}
		}
		return list_liststr;
	}
	
	/**
	 *   拆分包，获取指定的128bit,16bit的UUID ; local name ; manufacturer ; 发射功率 ; 自定义服务描述 ; 外设 ; 广播模式 ; 连接间隔 ; 签名数据 ; 服务列表16bit ; 服务列表128bit ; 
	 *                  完整16bitUUID ; 32bit ; 完整32bitUUID ; 完整128bitUUID ; 短的签名 ; 配对模式1 ; 配对模式2 ; 配对模式3 ; TK值 ; oob模式 ;
	 *                                     
	 * @param list  数据
	 * @return 返回数组 1:128bit ; 2:16bit ; 3:localname ; 4:manufacturer ; 5:power_level ; 6:service_data ; 7:apparance ; 8:flags ; 9:con_range ; 10:singe_data
	 *                                   11:service_list_16bit ; 12:service_list_128bit ; 13:16bit_complete ; 14:32bit_more ; 15:32bit_complete ; 16:128bit_complete ; 
	 *                                   17:localNameShort ; 18:配对模式(Class of device (3 octets)) ; 19:配对模式(Simple Pairing Hash C (16 octets)) ; 20:配对模式(Simple Pairing Randomizer R (16 octets))
	 *                                   21:TK value ; 22:oob flag ;
	 *                   默认为nulln
	 */
	public static String[] splitType(ArrayList<ArrayList<String>> list){
		String[] s=new String[22];
		int index=0;
		StringBuilder sb=null;
		for(int i=0;i<list.size();i++){
			if(list.get(i).size()>1){
				switch(Integer.parseInt(list.get(i).get(1),16)){
				case GAP_ADTYPE_128BIT_MORE:
					index=0;
					break;
				case GAP_ADTYPE_16BIT_MORE:
					index=1;
					break;
				case GAP_ADTYPE_LOCAL_NAME_COMPLETE:
					index=2;
					break;
				case GAP_ADTYPE_MANUFACTURER_SPECIFIC:
					index=3;
					break;
				case GAP_ADTYPE_POWER_LEVEL:
					index=4;
					break;
				case GAP_ADTYPE_SERVICE_DATA:
					index=5;
					break;
				case GAP_ADTYPE_APPEARANCE:
					index=6;
					break;
				case GAP_ADTYPE_FLAGS:
					index=7;
					break;
				case GAP_ADTYPE_SLAVE_CONN_INTERVAL_RANGE:
					index=8;
					break;
				case GAP_ADTYPE_SIGNED_DATA:
					index=9;
					break;
				case GAP_ADTYPE_SERVICES_LIST_16BIT:
					index=10;
					break;
				case GAP_ADTYPE_SERVICES_LIST_128BIT:
					index=11;
					break;
				case GAP_ADTYPE_16BIT_COMPLETE:
					index=12;
					break;
				case GAP_ADTYPE_32BIT_MORE:
					index=13;
					break;
				case GAP_ADTYPE_32BIT_COMPLETE:
					index=14;
					break;
				case GAP_ADTYPE_128BIT_COMPLETE:
					index=15;
					break;
				case GAP_ADTYPE_LOCAL_NAME_SHORT:
					index=16;
					break;
				case GAP_ADTYPE_OOB_CLASS_OF_DEVICE:
					index=17;
					break;
				case GAP_ADTYPE_OOB_SIMPLE_PAIRING_HASHC:
					index=18;
					break;
				case GAP_ADTYPE_OOB_SIMPLE_PAIRING_RANDR:
					index=19;
					break;
				case GAP_ADTYPE_SM_TK:
					index=20;
					break;
				case GAP_ADTYPE_SM_OOB_FLAG:
					index=21;
					break;
					default:
						index=-1;
						break;
				}
				
				if(index!=-1){
					sb=new StringBuilder();
					for(int j=2;j<list.get(i).size();j++){
						sb.append(list.get(i).get(j));
					}
					s[index]=sb.toString();
					int gaptype=Integer.parseInt(list.get(i).get(1),16);
					Log.i(decodeGapType(gaptype), s[index]);
				}
			}
		}
		return s;
	}

	/**
	 * 将指定时间加上一分钟的时间
	 * @param dateTime yyyy-MM-dd HH:mm
	 * @return
	 */
	public static String timePlus1Min(String dateTime){//yyy MM dd HH mm
		try {
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd HH:mm");
			long s=sf.parse(dateTime).getTime();
			s=s+(60*1000);
			return sf.format(new Date(s));
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	/**
	 *   获取指定时间段里面的所有时间
	 * @param startT
	 * @param endT
	 * @return
	 */
	public static ArrayList<String> dataTimes(String startT,String endT) {
		ArrayList<String> list=new ArrayList<String>();
		SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd HH:mm");
		try {
			String nextT=startT;
			long startTMills = sf.parse(nextT).getTime();
			long endTMills = sf.parse(endT).getTime();
			
			while(startTMills <= endTMills){
				
				list.add(nextT);
				nextT=timePlus1Min(nextT);
				startTMills =sf.parse(nextT).getTime();
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/**
	 *   将一个字节的数据转为2进制
	 * @param b
	 * @return
	 */
   public static String getBinaryStrFromByte(byte b){  
        String result ="";  
        byte a = b; ;  
        for (int i = 0; i < 8; i++){  
            byte c=a;  
            a=(byte)(a>>1);//每移一位如同将10进制数除以2并去掉余数。  
            a=(byte)(a<<1);  
            if(a==c){  
                result="0"+result;  
            }else{  
                result="1"+result;  
            }  
            a=(byte)(a>>1);  
        }  
        return result;  
    }  

   public static String decodeGapType(int gaptype){
	   String TAG="";
	   int index=0;
	   switch(gaptype){
		case GAP_ADTYPE_128BIT_MORE:
			TAG="GAP_ADTYPE_128BIT_MORE";
			index=0;
			break;
		case GAP_ADTYPE_16BIT_MORE:
			TAG="GAP_ADTYPE_16BIT_MORE";
			index=1;
			break;
		case GAP_ADTYPE_LOCAL_NAME_COMPLETE:
			TAG="GAP_ADTYPE_LOCAL_NAME_COMPLETE";
			index=2;
			break;
		case GAP_ADTYPE_MANUFACTURER_SPECIFIC:
			TAG="GAP_ADTYPE_MANUFACTURER_SPECIFIC";
			index=3;
			break;
		case GAP_ADTYPE_POWER_LEVEL:
			TAG="GAP_ADTYPE_POWER_LEVEL";
			index=4;
			break;
		case GAP_ADTYPE_SERVICE_DATA:
			TAG="GAP_ADTYPE_SERVICE_DATA";
			index=5;
			break;
		case GAP_ADTYPE_APPEARANCE:
			TAG="GAP_ADTYPE_APPEARANCE";
			index=6;
			break;
		case GAP_ADTYPE_FLAGS:
			TAG="GAP_ADTYPE_FLAGS";
			index=7;
			break;
		case GAP_ADTYPE_SLAVE_CONN_INTERVAL_RANGE:
			TAG="GAP_ADTYPE_SLAVE_CONN_INTERVAL_RANGE";
			index=8;
			break;
		case GAP_ADTYPE_SIGNED_DATA:
			TAG="GAP_ADTYPE_SIGNED_DATA";
			index=9;
			break;
		case GAP_ADTYPE_SERVICES_LIST_16BIT:
			TAG="GAP_ADTYPE_SERVICES_LIST_16BIT";
			index=10;
			break;
		case GAP_ADTYPE_SERVICES_LIST_128BIT:
			TAG="GAP_ADTYPE_SERVICES_LIST_128BIT";
			index=11;
			break;
		case GAP_ADTYPE_16BIT_COMPLETE:
			TAG="GAP_ADTYPE_16BIT_COMPLETE";
			index=12;
			break;
		case GAP_ADTYPE_32BIT_MORE:
			TAG="GAP_ADTYPE_32BIT_MORE";
			index=13;
			break;
		case GAP_ADTYPE_32BIT_COMPLETE:
			TAG="GAP_ADTYPE_32BIT_COMPLETE";
			index=14;
			break;
		case GAP_ADTYPE_128BIT_COMPLETE:
			TAG="GAP_ADTYPE_128BIT_COMPLETE";
			index=15;
			break;
		case GAP_ADTYPE_LOCAL_NAME_SHORT:
			TAG="GAP_ADTYPE_LOCAL_NAME_SHORT";
			index=16;
			break;
		case GAP_ADTYPE_OOB_CLASS_OF_DEVICE:
			TAG="GAP_ADTYPE_OOB_CLASS_OF_DEVICE";
			index=17;
			break;
		case GAP_ADTYPE_OOB_SIMPLE_PAIRING_HASHC:
			TAG="GAP_ADTYPE_OOB_SIMPLE_PAIRING_HASHC";
			index=18;
			break;
		case GAP_ADTYPE_OOB_SIMPLE_PAIRING_RANDR:
			TAG="GAP_ADTYPE_OOB_SIMPLE_PAIRING_RANDR";
			index=19;
			break;
		case GAP_ADTYPE_SM_TK:
			TAG="GAP_ADTYPE_SM_TK";
			index=20;
			break;
		case GAP_ADTYPE_SM_OOB_FLAG:
			TAG="GAP_ADTYPE_SM_OOB_FLAG";
			index=21;
			break;
			default:
				TAG="Unknown GapType...";
				index=-1;
				break;
		
	   }
	   return TAG;
   }
	
    public static String decodeReturnCode(int status){
		switch(status){
		case GATT_FAILURE: return "GATT_FAILURE";
		case GATT_INSUFFICIENT_AUTHENTICATION: return "GATT_INSUFFICIENT_AUTHENTICATION";
		case GATT_INSUFFICIENT_ENCRYPTION: return "GATT_INSUFFICIENT_ENCRYPTION";
		case GATT_INVALID_ATTRIBUTE_LENGTH: return "GATT_INVALID_ATTRIBUTE_LENGTH";
		case GATT_INVALID_OFFSET: return "GATT_INVALID_OFFSET";
		case GATT_READ_NOT_PERMITTED: return "GATT_READ_NOT_PERMITTED";
		case GATT_REQUEST_NOT_SUPPORTED: return "GATT_REQUEST_NOT_SUPPORTED";
		case GATT_SUCCESS: return "GATT_SUCCESS";
		case GATT_WRITE_NOT_PERMITTED: return "GATT_WRITE_NOT_PERMITTED";
		default: return "Unknown return code: " + status;
		}
    }
}
