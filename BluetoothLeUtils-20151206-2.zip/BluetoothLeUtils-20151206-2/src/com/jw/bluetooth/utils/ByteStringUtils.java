package com.jw.bluetooth.utils;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * 
 */
public class ByteStringUtils
{
	/**
	 * byte 2 String
	 * 
	 * @param indata
	 * @param indataLen
	 * @return
	 */
	public static String ByteArrayToString(byte[] indata, int indataLen)
	{
		try
		{
			int g_RespLen = indataLen;
			byte[] g_Response = indata;

			int m = 0;
			StringBuffer mStringBuffer = new StringBuffer();
			while (m < g_RespLen)
			{
				if ((g_Response[m] & 0xF0) == 0x00)
				{
					mStringBuffer.append("0");
					mStringBuffer.append(Integer.toHexString((short) (0x00FF & g_Response[m])));
				}
				else
				{
					mStringBuffer.append(Integer.toHexString((short) (0x00FF & g_Response[m])));
				}
				m++;
			}
			return mStringBuffer.toString().toUpperCase(Locale.US);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}

	}

	/**
	 * 
	 * @param iStr
	 * @return
	 */
	public static byte[] stringToByteArr(String iStr)
	{
		iStr = iStr.replaceAll(" ", "");
		iStr = iStr.replaceAll(System.getProperty("line.separator"), "");
		iStr = iStr.replaceAll("\n", "");
		iStr = iStr.replaceAll("\t", "");
		if (iStr.length() == 0)
		{
			return null;
		}
		if (iStr.length() % 2 != 0)
		{
			iStr += "F";
		}
		else
		{

		}
		byte[] outArr = new byte[iStr.length() / 2];
		byte b = 0;
		String hex = "";

		for (int i = 0; i < iStr.length(); i += 2)
		{
			hex = iStr.substring(i, i + 2);
			try
			{
				if (hex.equalsIgnoreCase(null) || hex.equalsIgnoreCase(""))
				{
					break;
				}
				b = (byte) ((int) Integer.parseInt(hex, 16) & 0xFF);
			}
			catch (Exception e)
			{
				e.printStackTrace();
				break;
			}

			outArr[i / 2] = b;
		}
		return outArr;
	}

	/**
	 * GBK 2 String
	 * 
	 * @param indata
	 * @return
	 */
	public String GBK2String(String indata)
	{
		if (indata == null)
		{
			return null;
		}

		String finalDataString = null;

		byte[] indataByte = ByteStringUtils.stringToByteArr(indata);
		try
		{
			finalDataString = new String(indataByte, "GBK");
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
			return null;
		}

		return finalDataString;
	}

	/**
	 * String 2 GBK
	 * 
	 * @param indata
	 * @return
	 */
	public static String string2GBK(String indata)
	{
		if (indata == null)
		{
			return null;
		}

		byte[] GBKDataBytes;

		try
		{
			GBKDataBytes = indata.getBytes("GBK");
		}
		catch (UnsupportedEncodingException e1)
		{
			e1.printStackTrace();
			return null;
		}

		String GBKDataString = ByteStringUtils.ByteArrayToString(GBKDataBytes, GBKDataBytes.length);
		return GBKDataString;
	}

	/**
	 * ���ߺ���GBK coding to character String , eg. 0x31b6d432 to "1��2"
	 * 
	 * @param cArray
	 *            HEX value
	 * @return ���к��ֵ��ַ�
	 */
	public static String GBK2Sring(String gbkEncoding)
	{
		String sResult = "";
		String sTmp = "";
		char c1, c2;
		int index = 0;

		// String to Chinese , eg. "31b6d432" to "1��2"
		index = 0;
		while (index < gbkEncoding.length())
		{
			if (gbkEncoding.charAt(index) >= '0' && gbkEncoding.charAt(index) <= '9')
			{
				// ASCII , eg. "31" to '1', "41" to 'A'
				c1 = (char) ((gbkEncoding.charAt(index) - '0') * 16);
				c2 = gbkEncoding.charAt(index + 1);
				if (c2 >= '0' && c2 <= '9')
				{
					c2 -= '0';
				}
				else if (c2 >= 'A' && c2 <= 'F')
				{
					c2 -= 'A' - 10;
				}
				else if (c2 >= 'a' && c2 <= 'f')
				{
					c2 -= 'a' - 10;
				}
				c1 += c2;
				sResult += c1;
				index += 2;
			}
			else
			{
				// GBK , eg. "b6d4" to "��"
				sTmp = gbkEncoding.substring(index, index + 4);
				sResult += toGbkChar(sTmp);
				index += 4;
			}
		}
		return sResult;
	}

	/**
	 * String2 UTF-8
	 * 
	 * @param indata
	 * @return
	 */
	public static String string2UTF8(String indata)
	{
		if (indata == null)
		{
			return null;
		}

		if (indata.equals(""))
		{
			return "";
		}

		byte[] GBKDataBytes;

		try
		{
			GBKDataBytes = indata.getBytes("UTF-8");
		}
		catch (UnsupportedEncodingException e1)
		{
			e1.printStackTrace();
			return null;
		}

		String GBKDataString = ByteStringUtils.ByteArrayToString(GBKDataBytes, GBKDataBytes.length);
		return GBKDataString;
	}

	/**
	 * UTF-8 2 String
	 * 
	 * @param indata
	 * @return
	 */
	public static String UTF82String(String indata)
	{
		if (indata == null)
		{
			return null;
		}

		String finalDataString = null;

		byte[] indataByte = ByteStringUtils.stringToByteArr(indata);
		try
		{
			finalDataString = new String(indataByte, "UTF-8");
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
			return null;
		}

		return finalDataString;
	}

	private final static char[] HEX =
	{ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

	/**
	 * ���ߺ���GBK coding to character String , eg. 0x31b6d432 to "1��2"
	 * 
	 * @param cArray
	 *            HEX value
	 * @return ���к��ֵ��ַ�
	 */
	public static String GBKtoSring(String gbkEncoding)
	{
		String sResult = "";
		String sTmp = "";
		char c1, c2;
		int index = 0;

		// String to Chinese , eg. "31b6d432" to "1��2"
		index = 0;
		while (index < gbkEncoding.length())
		{
			if (gbkEncoding.charAt(index) >= '0' && gbkEncoding.charAt(index) <= '9')
			{
				// ASCII , eg. "31" to '1', "41" to 'A'
				c1 = (char) ((gbkEncoding.charAt(index) - '0') * 16);
				c2 = gbkEncoding.charAt(index + 1);
				if (c2 >= '0' && c2 <= '9')
				{
					c2 -= '0';
				}
				else if (c2 >= 'A' && c2 <= 'F')
				{
					c2 -= 'A' - 10;
				}
				else if (c2 >= 'a' && c2 <= 'f')
				{
					c2 -= 'a' - 10;
				}
				c1 += c2;
				sResult += c1;
				index += 2;
			}
			else
			{
				// GBK , eg. "b6d4" to "��"
				sTmp = gbkEncoding.substring(index, index + 4);
				sResult += toGbkChar(sTmp);
				index += 4;
			}
		}
		return sResult;
	}

	public static char toGbkChar(String gbkEncoding)
	{
		if (gbkEncoding == null || !gbkEncoding.matches("[0-9a-fA-F]{4}"))
		{
			throw new IllegalArgumentException("GBK encoding data error!");
		}
		int num = Integer.parseInt(gbkEncoding, 16);
		if (num < 0 || num > 0xffff)
		{
			throw new IllegalArgumentException("GBK encoding data error!");
		}
		byte[] bys = new byte[2];
		bys[0] = (byte) (num >> 8 & 0xff);
		bys[1] = (byte) (num & 0xff);

		if (bys == null || bys.length != 2)
		{
			throw new IllegalArgumentException("GBK encoding byte length must be 2");
		}
		String str = null;
		try
		{
			str = new String(bys, "gbk");
		}
		catch (UnsupportedEncodingException e)
		{
			throw new IllegalArgumentException("GBK encoding convert error!");
		}
		if (str == null)
		{
			throw new IllegalArgumentException("GBK encoding convert error!");
		}
		return str.charAt(0);
	}

	public static boolean StringToBCD(char[] oldData, int inLen, char[] newData, int outLen[])
	{

		char[] buff = new char[inLen];
		char j, k;
		int i;

		Arrays.fill(buff, (char) 0xFF);
		Arrays.fill(newData, (char) 0xFF);
		outLen[0] = (inLen + inLen % 2) / 2;

		// ���ַ��BCD��ת��
		for (i = 0; i < inLen; i++)
		{
			if (oldData[i] >= '0' && oldData[i] <= '9')
			{
				buff[i] = (char) (oldData[i] - 0x30);
			}
			else if (oldData[i] >= 'a' && oldData[i] <= 'f')
			{
				buff[i] = (char) (oldData[i] - 0x57);
			}
			else if (oldData[i] >= 'A' && oldData[i] <= 'F')
			{
				buff[i] = (char) (oldData[i] - 0x37);
			}
			else
			{
				return false;
			}
		}

		// �����ַ�ϳ�һ���ֽ�
		for (i = 0; i < (outLen[0] - 1); i++)
		{
			j = buff[2 * i];
			k = buff[2 * i + 1];
			newData[i] = (char) ((char) j << 4 & (char) 0xF0);
			newData[i] |= (char) (k & (char) 0x0F);
		}
		j = buff[2 * i];
		newData[i] = (char) ((char) j << 4 & (char) 0xF0);

		// ���ַ����ż�Ĵ���
		if ((inLen % 2) != 0)
		{
			newData[i] |= (char) 0x0F;
		}
		else
		{
			k = buff[2 * i + 1];
			newData[i] |= (char) (k & (char) 0x0F);
		}
		return true;
	}

	public static int StringToBCD(String oldData, int inLen, byte[] newData, int offset)
	{
		char[] outData = new char[(inLen + inLen % 2) / 2];
		int[] len = new int[1];
		boolean result;

		result = StringToBCD(oldData.toCharArray(), oldData.length(), outData, len);

		if (result)
		{
			for (int i = 0; i < len[0]; i++)
			{
				newData[offset + i] = (byte) outData[i];
			}
			return len[0];
		}
		else
		{
			return 0;
		}

	}

	public static byte[] toBytes(int a)
	{
		return new byte[]
		{ (byte) (0x000000ff & (a >>> 24)), (byte) (0x000000ff & (a >>> 16)), (byte) (0x000000ff & (a >>> 8)),
				(byte) (0x000000ff & (a)) };
	}

	public static int toInt(byte[] b, int s, int n)
	{
		int ret = 0;

		final int e = s + n;
		for (int i = s; i < e; ++i)
		{
			ret <<= 8;
			ret |= b[i] & 0xFF;
		}
		return ret;
	}

	public static int toInt(byte... b)
	{
		int ret = 0;
		for (final byte a : b)
		{
			ret <<= 8;

			ret |= a & 0xFF;
		}
		return ret;
	}

	public static String toHexString(byte[] d, int s, int n)
	{
		final char[] ret = new char[n * 2];
		final int e = s + n;

		int x = 0;
		for (int i = s; i < e; ++i)
		{
			final byte v = d[i];
			ret[x++] = HEX[0x0F & (v >> 4)];
			ret[x++] = HEX[0x0F & v];
		}
		return new String(ret);
	}

	public static String toHexStringR(byte[] d, int s, int n)
	{
		final char[] ret = new char[n * 2];

		int x = 0;
		for (int i = s + n - 1; i >= s; --i)
		{
			final byte v = d[i];
			ret[x++] = HEX[0x0F & (v >> 4)];
			ret[x++] = HEX[0x0F & v];
		}
		return new String(ret);
	}

	public static int parseInt(String txt, int radix, int def)
	{
		int ret;
		try
		{
			ret = Integer.valueOf(txt, radix);
		}
		catch (Exception e)
		{
			ret = def;
		}

		return ret;
	}

	public static String ByteArrayToString(byte[] indata, int offset, int len_indata)
	{

		int g_RespLen = len_indata;
		byte[] g_Response = indata;

		int m = offset;
		String g_InfoString = "";

		while (m < (offset + g_RespLen))
		{
			if ((g_Response[m] & 0xF0) == 0x00)
			{
				g_InfoString += '0' + Integer.toHexString((short) (0x00FF & g_Response[m]));
			}
			else
			{
				g_InfoString += Integer.toHexString((short) (0x00FF & g_Response[m]));
			}
			m++;
		}

		return g_InfoString;
	}

	public static short getShort(byte[] src, short srcoffset)
	{
		short result = 0;

		result = (short) (((src[srcoffset + 0] << 8) | src[srcoffset + 1] & 0xff));

		return result;
	}

	/**
	 * ���ת�� eg 000000000001 -> 0.01
	 * 
	 * @param newBalanceString
	 * @return
	 */
	public static String format2Amount(String newBalanceString)
	{
		while (newBalanceString.length() < 12)
		{
			newBalanceString = "0" + newBalanceString;
		}
		newBalanceString = newBalanceString.substring(0, 10) + "." + newBalanceString.substring(10, 12);

		int i = 0;
		String newBalanceStringFinal = "";

		for (i = 0; i < 10; i++)
		{
			if (!newBalanceString.substring(i, i + 1).equals("0"))
			{
				newBalanceStringFinal = newBalanceString.substring(i, 13);
				break;
			}
		}

		if (i == 10)
		{
			newBalanceStringFinal = "0." + newBalanceString.substring(11, 13);
		}
		String balance = newBalanceStringFinal;
		return balance;
	}

	/**
	 * ���ת�� eg 0.01 -> 000000000001
	 * 
	 * @param transAmount
	 * @return
	 */
	public static String amount2Format(String transAmount)
	{
		int i = 0;

		while (i < transAmount.length())
		{
			if (transAmount.charAt(i) == '.')
			{
				if ((transAmount.length() - i - 1) == 2)
				{
					break;
				}
				else if ((transAmount.length() - i - 1) == 1)
				{
					transAmount += '0';
					break;
				}
				else if ((transAmount.length() - i - 1) == 0)
				{
					transAmount += "00";
					break;
				}
			}
			i++;
		}
		if (i == transAmount.length())
		{
			// amount = transAmount + '.' + "00";
			// no decimal point
			transAmount += "00";
			while (transAmount.length() < 12)
			{
				transAmount = '0' + transAmount;
			}
		}
		else
		{
			// amount = transAmount;
			// get rid of decimal point
			transAmount = transAmount.substring(0, i) + transAmount.substring(i + 1, transAmount.length());
			while (transAmount.length() < 12)
			{
				transAmount = '0' + transAmount;
			}
		}

		return transAmount;
	}

	public static String gbToUtf8(String str) throws UnsupportedEncodingException
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < str.length(); i++)
		{
			String s = str.substring(i, i + 1);
			if (s.charAt(0) > 0x80)
			{
				byte[] bytes = s.getBytes("Unicode");
				String binaryStr = "";
				for (int j = 2; j < bytes.length; j += 2)
				{
					// the first byte
					String hexStr = getHexString(bytes[j + 1]);
					String binStr = getBinaryString(Integer.valueOf(hexStr, 16));
					binaryStr += binStr;
					// the second byte
					hexStr = getHexString(bytes[j]);
					binStr = getBinaryString(Integer.valueOf(hexStr, 16));
					binaryStr += binStr;
				}
				// convert unicode to utf-8
				String s1 = "1110" + binaryStr.substring(0, 4);
				String s2 = "10" + binaryStr.substring(4, 10);
				String s3 = "10" + binaryStr.substring(10, 16);
				byte[] bs = new byte[3];
				bs[0] = Integer.valueOf(s1, 2).byteValue();
				bs[1] = Integer.valueOf(s2, 2).byteValue();
				bs[2] = Integer.valueOf(s3, 2).byteValue();
				String ss = new String(bs, "UTF-8");
				sb.append(ss);
			}
			else
			{
				sb.append(s);
			}
		}
		return sb.toString();
	}

	private static String getHexString(byte b)
	{
		String hexStr = Integer.toHexString(b);
		int m = hexStr.length();
		if (m < 2)
		{
			hexStr = "0" + hexStr;
		}
		else
		{
			hexStr = hexStr.substring(m - 2);
		}
		return hexStr;
	}

	private static String getBinaryString(int i)
	{
		String binaryStr = Integer.toBinaryString(i);
		int length = binaryStr.length();
		for (int l = 0; l < 8 - length; l++)
		{
			binaryStr = "0" + binaryStr;
		}
		return binaryStr;
	}

	public static String transMapToString(Map<String, String> map)
	{
		java.util.Map.Entry entry;
		StringBuffer sb = new StringBuffer();
		for (Iterator iterator = map.entrySet().iterator(); iterator.hasNext();)
		{
			entry = (java.util.Map.Entry) iterator.next();
			sb.append(entry.getKey().toString()).append("'").append(null == entry.getValue() ? "" : entry.getValue().toString())
					.append(iterator.hasNext() ? "^" : "");
		}
		return sb.toString();
	}

	public static Map<String, String> transStringToMap(String mapString)
	{
		Map<String, String> map = new HashMap<String, String>();
		java.util.StringTokenizer items;
		for (StringTokenizer entrys = new StringTokenizer(mapString, "^"); entrys.hasMoreTokens(); map.put(items.nextToken(),
				(String) (items.hasMoreTokens() ? ((Object) (items.nextToken())) : null)))
			items = new StringTokenizer(entrys.nextToken(), "'");
		return map;
	}

	public static byte[] int2byte(int res)
	{
		byte[] targets = new byte[2];

		targets[1] = (byte) (res & 0xff);
		targets[0] = (byte) ((res >> 8) & 0xff);
		return targets;
	}

	public static String printHexString(byte[] b)
	{
		String a = "";
		for (int i = 0; i < b.length; i++)
		{
			String hex = Integer.toHexString(b[i] & 0xFF);
			if (hex.length() == 1)
			{
				hex = '0' + hex;
			}
			a = a + hex;
		}
		return a;
	}

	public static String getStringLen(String str)
	{
		try
		{
			if (str == null)
			{
				return null;
			}
			if (str.equals(""))
			{
				return "00";
			}
			if (str.length() % 2 == 1)
			{
				return null;
			}
			byte indata[] = new byte[1];
			indata[0] = (byte) (str.length() / 2);
			String strLength = ByteStringUtils.ByteArrayToString(indata, 1);
			return strLength;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	public static String getHex2String(byte indata)
	{
		byte tmp[] = new byte[1];
		tmp[0] = indata;
		return ByteStringUtils.ByteArrayToString(tmp, 1);
	}

	/**8位二进制字符串转换为byte
	 * 
	 * @param str
	 * @return
	 */
	public static byte getByteFromString(String str){
		byte b=0;
		for(int i=0;i<8;i++){
			if(str.charAt(i)=='1'){
				b+=1<<i;
			}
		}
		return b;
	}
	

	/** 
	* Convert byte[] to hex string. 把字节数组转化为字符串 
	* 这里我们可以将byte转换成int，然后利用Integer.toHexString(int)来转换成16进制字符串。 
	* @param src byte[] data 
	* @return hex string 
	*/     
   public static String bytesToHexString(byte[] src){  
	   StringBuilder stringBuilder = new StringBuilder("");  
   		if (src == null || src.length <= 0) {  
   			return null;  
   		}  
   		for (int i = 0; i < src.length; i++) {  
   			int v = src[i] & 0xFF;  
   			String hv = Integer.toHexString(v);  
   			if (hv.length() < 2) {  
   				stringBuilder.append("0");  
   			}  
           stringBuilder.append(hv+" ");  
       }  
       return stringBuilder.toString().toUpperCase();  
   } 
   
	/**
	 *   解析LocalName
	 * @param s 16进制组合的数据
	 * @return LocalName
	 */
	public static String toStringHex(String s){
		try{
			if(s!=null && s.length()>2){
				byte[] baKeyword = new byte[s.length()/2];
				for(int i = 0; i < baKeyword.length; i++){
					baKeyword[i] = (byte)(0xff & Integer.parseInt(s.substring(i*2, i*2+2),16));//????可能有问题
				}
				s = new String(baKeyword, "utf-8");//UTF-16le:Not
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return s;
	}
	
	/**********************************************************************/
	/**
	 * 
	 * @param bytes[4]
	 * @return
	 */
	public static int getInt(byte[] bytes)
    {
        return (0xff & bytes[0]) | (0xff00 & (bytes[1] << 8)) | (0xff0000 & (bytes[2] << 16)) | (0xff000000 & (bytes[3] << 24));
    }
	/**
	 * 
	 * @param data int
	 * @return byte[4]
	 */
    public static byte[] getBytes(int data)
    {
        byte[] bytes = new byte[4];
        bytes[0] = (byte) (data & 0xff);
        bytes[1] = (byte) ((data & 0xff00) >> 8);
        bytes[2] = (byte) ((data & 0xff0000) >> 16);
        bytes[3] = (byte) ((data & 0xff000000) >> 24);
        return bytes;
    }
	
	public static byte[] get3Byte(int x){
		byte[] bt=new byte[3];
		int y= x & 0xFFFFFF;
		
		bt[0]=(byte) (y & 0xFF);
		bt[1]=(byte) ((y>>8) & 0xFF);
		bt[2]=(byte)((y>>16) & 0xFF);
		return bt;
	}
	/**
	 * 
	 * @param bts[3]
	 * @return
	 */
	public static int getIntFrom3Byte(byte[] bts){
		return getInt(new byte[]{bts[0],bts[1],bts[2],0x00});
	}
	
	public static byte[] get2Byte(int x){
		byte[] bt=new byte[2];
		int y= x & 0x0FFFF;
		
		bt[0]=(byte) (y & 0x0FF);
		bt[1]=(byte) ((y>>8) & 0x0FF);
		return bt;
	}
	public static int getIntFrom2Byte(byte[] bts){
		return getInt(new byte[]{bts[0],bts[1],0x00,0x00});
	}
	
	public static byte[] byteList2ByteArray(ArrayList<Byte> byteList){
		byte[] bytes=null;
		if(byteList!=null && byteList.size()>0){
			bytes=new byte[byteList.size()];
			for(int i=0;i<byteList.size();i++){
				bytes[i]=byteList.get(i);
			}
		}
		return bytes;
	}
	
	
  public static byte loUint16(short v) {
    return (byte) (v & 0xFF);
  }

  public static byte hiUint16(short v) {
    return (byte) (v >> 8);
  }

  public static short buildUint16(byte hi, byte lo) {
    return (short) ((hi << 8) + (lo & 0xff));
  }
  /**
   * 字节数据转换为Hex String,带分隔符“：”
   * @param b
   * @param reverse 正向、反向
   * @return 正向（AB：CD：EF：12：34：56）；反向（ 65：43:21：FE：DC：BA）
   */
  public static String Byte2hexString(byte[] b, boolean reverse) {
    StringBuilder sb = new StringBuilder(b.length * (2 + 1));
    Formatter formatter = new Formatter(sb);
    if (!reverse) {
      for (int i = 0; i < b.length; i++) {
        if (i < b.length - 1)
          formatter.format("%02X:", b[i]);
        else
          formatter.format("%02X", b[i]);
      }
    } else {
      for (int i = (b.length - 1); i >= 0; i--) {
        if (i > 0)
          formatter.format("%02X:", b[i]);
        else
          formatter.format("%02X", b[i]);
      }
    }
    formatter.close();
    return sb.toString();
  }

  /**
   * 字节数据转换为Hex String,不带分隔符“：”
   * @param b
   * @return ABCDEF123456
   */
  public static String Byte2hexString(byte[] b) {
    StringBuilder sb = new StringBuilder(b.length * (2 + 1));
    Formatter formatter = new Formatter(sb);
    for (int i = 0; b!=null && i < b.length; i++) {
      if (i < b.length - 1)
        formatter.format("%02X", b[i]);
      else
        formatter.format("%02X", b[i]);
    }
    formatter.close();
    return sb.toString();
  }
  /** 
   * Convert hex String to Byte
   * @param sb
   * @return results
   */
  public static ArrayList<Byte> hexStringtoByteList(String sb) {
	  	int i = 0;
	    boolean j = false;
	    ArrayList<Byte> byteList=new ArrayList<Byte>();
	    if (sb != null) {
	      for (int k = 0; k < sb.length(); k++) {
	        if (((sb.charAt(k)) >= '0' && (sb.charAt(k) <= '9')) 
	        		|| ((sb.charAt(k)) >= 'a' && (sb.charAt(k) <= 'f'))
	        		|| ((sb.charAt(k)) >= 'A' && (sb.charAt(k) <= 'F'))) {
	          if (j) {
	            byteList.set(i,(byte) (byteList.get(i)+(Character.digit(sb.charAt(k), 16))));
	            i++;
	          } else {
	        	  byteList.add(i, (byte) (Character.digit(sb.charAt(k), 16) << 4));
	          }
	          j = !j;
	        }
	      }
	    }
	    return byteList;
  }

  public static boolean isAsciiPrintable(String str) {
    if (str == null) {
      return false;
    }
    int sz = str.length();
    for (int i = 0; i < sz; i++) {
      if (isAsciiPrintable(str.charAt(i)) == false) {
        return false;
      }
    }
    return true;
  }

  private static boolean isAsciiPrintable(char ch) {
    return ch >= 32 && ch < 127;
  }

}
