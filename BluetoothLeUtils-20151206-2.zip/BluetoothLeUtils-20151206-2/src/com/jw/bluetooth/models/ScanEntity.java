package com.jw.bluetooth.models;

import java.util.Arrays;

import android.bluetooth.BluetoothDevice;

public class ScanEntity implements Comparable<ScanEntity>{
	private String mac;
	private String name;
	private BluetoothDevice device;
	private int rssi;
	private byte[] scanRecord;
	private int state=0;//连接状态:0-默认	-1:断开设备	100：连接成功	404:未工作（未广播，找不到）
	private String[] scanRecordstr;
	
	public ScanEntity() {
		super();
	}
	
	public ScanEntity(BluetoothDevice device, int rssi, byte[] scanRecord,
			int state) {
		super();
		this.device = device;
		if(this.device!=null){
			this.name = this.device.getName();
			this.mac = this.device.getAddress();
		}
		this.rssi = rssi;
		this.scanRecord = scanRecord;
		this.state = state;
	}

	public ScanEntity(BluetoothDevice device,int rssi, byte[] scanRecord,
			 int state, String[] scanRecordstr) {
		super();
		this.rssi = rssi;
		this.scanRecord = scanRecord;
		this.device = device;
		if(this.device!=null){
			this.name = this.device.getName();
			this.mac = this.device.getAddress();
		}
		this.state = state;
		this.scanRecordstr = scanRecordstr;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public int getRssi() {
		return rssi;
	}
	public void setRssi(int rssi) {
		this.rssi = rssi;
	}
	public byte[] getScanRecord() {
		return scanRecord;
	}
	public void setScanRecord(byte[] scanRecord) {
		this.scanRecord = scanRecord;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BluetoothDevice getDevice() {
		return device;
	}
	public void setDevice(BluetoothDevice device) {
		this.device = device;
		if(this.device!=null){
			this.name = this.device.getName();
			this.mac = this.device.getAddress();
		}
	}
	
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String[] getScanRecordstr() {
		return scanRecordstr;
	}
	public void setScanRecordstr(String[] scanRecordstr) {
		this.scanRecordstr = scanRecordstr;
	}
	
	@Override
	public String toString() {
		return "ScanEntity [mac=" + mac + ", rssi=" + rssi + ", scanRecoder="
				+ Arrays.toString(scanRecord) + ", name=" + name + ", device="
				+ device + ", scanRecodestr=" + Arrays.toString(scanRecordstr)
				+ "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
//		result = prime * result + (isPass ? 1231 : 1237);
		result = prime * result + ((mac == null) ? 0 : mac.hashCode());
//		result = prime * result + ((name == null) ? 0 : name.hashCode());
//		result = prime * result + rssi;
//		result = prime * result + Arrays.hashCode(scanRecoder);
		return result;
	}
	
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		ScanEntity other = (ScanEntity) obj;
//		if (mac == null) {
//			if (other.mac != null)
//				return false;
//		} else if (!mac.equals(other.mac)){
//			return false;
//		}
//		return true;
//	}
	

	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		ScanEntity another=null;
		if(o!=null){
			if(o instanceof ScanEntity){
				another=(ScanEntity)o;
				if(another.getDevice()==device){
					return true;
				}
			}
		}
		return false;
	}
	
	@Override
	public int compareTo(ScanEntity another) {
		// TODO Auto-generated method stub
		if(this.rssi>another.getRssi()){
			return 1;
		}
		if(this.rssi<another.getRssi()){
			return -1;
		}
		return 0;
	}
	
}
