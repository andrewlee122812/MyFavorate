package com.jw.bluetooth.models;

public enum ENABLE{
	NONE,NOTIFY,INDICATE,BOTH
}
